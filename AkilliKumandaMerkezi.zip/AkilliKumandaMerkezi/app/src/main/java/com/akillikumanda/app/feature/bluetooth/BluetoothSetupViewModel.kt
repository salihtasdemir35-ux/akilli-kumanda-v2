package com.akillikumanda.app.feature.bluetooth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.akillikumanda.app.core.designsystem.BannerKind
import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.DeviceCategory
import com.akillikumanda.app.data.remote.ConnectedProfiles
import com.akillikumanda.app.data.remote.SaveResult
import com.akillikumanda.app.data.remote.SavedRemoteRepository
import com.akillikumanda.app.feature.discovery.StatusMessage
import com.akillikumanda.app.feature.network.NetworkSetupViewModel
import com.akillikumanda.app.platform.bluetooth.BluetoothConfig
import com.akillikumanda.app.platform.bluetooth.BluetoothHidRemote
import com.akillikumanda.app.platform.bluetooth.BondedDevice
import com.akillikumanda.app.platform.bluetooth.HidState
import com.akillikumanda.app.platform.infrared.TransmitResult
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class BtUiState(
    val bonded: List<BondedDevice> = emptyList(),
    val sending: Boolean = false,
    val sentOk: Boolean = false,
    val confirmed: Boolean = false,
    val name: String = "",
    val room: String = "",
    val status: StatusMessage? = null,
    val savedId: Long? = null,
    val duplicateId: Long? = null,
    val permissionDeniedOnce: Boolean = false,
)

class BluetoothSetupViewModel(
    val hid: BluetoothHidRemote,
    private val repo: SavedRemoteRepository,
    private val category: DeviceCategory,
) : ViewModel() {
    private val _s = MutableStateFlow(BtUiState())
    val state: StateFlow<BtUiState> = _s.asStateFlow()
    val hidState: StateFlow<HidState> = hid.state

    init { refresh() }

    fun refresh() {
        hid.start()
        _s.update { it.copy(bonded = hid.bondedDevices()) }
    }

    fun onPermissionResult(granted: Boolean) {
        _s.update { it.copy(permissionDeniedOnce = !granted) }
        refresh()
    }

    fun connect(address: String) {
        if (!hid.connect(address)) _s.update { it.copy(status = StatusMessage(
            "Bağlantı başlatılamadı. TV'de Bluetooth açık olmalı; olmazsa eşleştirmeyi TV'nin ayarlarından başlatın.", BannerKind.WARNING)) }
    }

    fun send(commandId: String) {
        if (_s.value.sending) return
        _s.update { it.copy(sending = true) }
        viewModelScope.launch {
            val r = hid.send(commandId)
            _s.update {
                it.copy(sending = false, sentOk = it.sentOk || r == TransmitResult.Success,
                    status = if (r == TransmitResult.Success)
                        StatusMessage("\"${CommandIds.label(commandId)}\" Bluetooth ile gönderildi. TV tepki verdi mi?", BannerKind.INFO)
                    else StatusMessage(NetworkSetupViewModel.describe(r), BannerKind.ERROR))
            }
        }
    }

    fun worked() {
        val c = hid.state.value as? HidState.Connected ?: return
        if (!_s.value.sentOk) return
        _s.update { it.copy(confirmed = true, name = c.name ?: "Bluetooth TV") }
    }

    fun notWorked() = _s.update { it.copy(status = StatusMessage(
        "Bu TV, Bluetooth klavye/medya tuşlarını kumanda olarak işlemiyor olabilir. Wi-Fi veya IR yöntemini deneyin. Hiçbir şey kaydedilmedi.",
        BannerKind.WARNING)) }

    fun setName(v: String) = _s.update { it.copy(name = v.take(60), duplicateId = null) }
    fun setRoom(v: String) = _s.update { it.copy(room = v.take(40)) }

    fun save() {
        val c = hid.state.value as? HidState.Connected ?: run {
            _s.update { it.copy(status = StatusMessage("Kaydetmek için TV bağlı olmalı.", BannerKind.ERROR)) }; return
        }
        val profile = ConnectedProfiles.forBluetooth(c.name, c.address, category)
        viewModelScope.launch {
            when (val r = repo.saveConfirmed(profile, _s.value.name, _s.value.room, null, BluetoothConfig(c.address, c.name).encode())) {
                is SaveResult.Saved -> _s.update { it.copy(savedId = r.id) }
                is SaveResult.Duplicate -> _s.update { it.copy(duplicateId = r.existingId, status = StatusMessage("Bu adla zaten kayıtlı.", BannerKind.WARNING)) }
                is SaveResult.Invalid -> _s.update { it.copy(status = StatusMessage(r.reason, BannerKind.ERROR)) }
            }
        }
    }
}
