package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.json.MiniJson
import com.akillikumanda.app.core.json.bool
import com.akillikumanda.app.core.json.long
import com.akillikumanda.app.core.json.obj
import com.akillikumanda.app.core.json.str
import com.akillikumanda.app.core.model.CommandIds

sealed interface LgMessage {
    data class Registered(val id: String?, val clientKey: String?) : LgMessage
    data class PromptShown(val id: String?) : LgMessage
    data class Response(val id: String?, val payload: Map<String, Any?>) : LgMessage
    data class Error(val id: String?, val error: String) : LgMessage
    data object Unknown : LgMessage
}

/** LG webOS ikinci ekran (SSAP) protokolü. Port 3001 (wss) yeni yazılımlarda, 3000 (ws) eski yazılımlarda. */
object LgProtocol {
    const val WS_PORT = 3000
    const val WSS_PORT = 3001

    /** Doğrudan SSAP isteğiyle gönderilen komutlar. */
    val REQUESTS = mapOf(
        CommandIds.VOL_UP to "ssap://audio/volumeUp",
        CommandIds.VOL_DOWN to "ssap://audio/volumeDown",
        CommandIds.CH_UP to "ssap://tv/channelUp",
        CommandIds.CH_DOWN to "ssap://tv/channelDown",
        CommandIds.POWER to "ssap://system/turnOff",
    )
    /** İşaretçi (pointer) soketi üzerinden düğme olarak gönderilen komutlar. */
    val BUTTONS = mapOf(
        CommandIds.UP to "UP", CommandIds.DOWN to "DOWN", CommandIds.LEFT to "LEFT", CommandIds.RIGHT to "RIGHT",
        CommandIds.OK to "ENTER", CommandIds.BACK to "BACK", CommandIds.HOME to "HOME", CommandIds.MENU to "MENU",
    )
    const val MUTE_URI = "ssap://audio/setMute"
    const val GET_VOLUME_URI = "ssap://audio/getVolume"
    const val SYSTEM_INFO_URI = "ssap://system/getSystemInfo"
    const val POINTER_URI = "ssap://com.webos.service.networkinput/getPointerInputSocket"

    val COMMANDS: List<String> = (REQUESTS.keys + BUTTONS.keys + CommandIds.MUTE).toList()

    private val PERMISSIONS = listOf(
        "LAUNCH", "CONTROL_AUDIO", "CONTROL_DISPLAY", "CONTROL_INPUT_JOYSTICK", "CONTROL_INPUT_MEDIA_PLAYBACK",
        "CONTROL_INPUT_TV", "CONTROL_POWER", "CONTROL_MOUSE_AND_KEYBOARD", "READ_APP_STATUS",
        "READ_CURRENT_CHANNEL", "READ_INPUT_DEVICE_LIST", "READ_NETWORK_STATE", "READ_POWER_STATE",
        "READ_TV_CHANNEL_LIST", "READ_COUNTRY_INFO", "WRITE_NOTIFICATION_TOAST",
    )

    fun url(ip: String, secure: Boolean) = if (secure) "wss://$ip:$WSS_PORT" else "ws://$ip:$WS_PORT"

    fun registerMessage(clientKey: String?): String {
        val payload = linkedMapOf<String, Any?>(
            "forcePairing" to false, "pairingType" to "PROMPT",
            "manifest" to mapOf("manifestVersion" to 1, "appVersion" to "1.0", "permissions" to PERMISSIONS),
        )
        if (!clientKey.isNullOrBlank()) payload["client-key"] = clientKey
        return MiniJson.stringify(mapOf("type" to "register", "id" to "register_0", "payload" to payload))
    }

    fun request(id: String, uri: String, payload: Map<String, Any?> = emptyMap()): String =
        MiniJson.stringify(mapOf("type" to "request", "id" to id, "uri" to uri, "payload" to payload))

    fun button(name: String) = "type:button\nname:$name\n\n"

    fun parse(text: String): LgMessage {
        val m = MiniJson.parseObjectOrNull(text) ?: return LgMessage.Unknown
        val id = m.str("id")
        val payload = m.obj("payload") ?: emptyMap()
        return when (m.str("type")) {
            "registered" -> LgMessage.Registered(id, payload.str("client-key"))
            "response" ->
                if (payload.str("pairingType") == "PROMPT" && id == "register_0") LgMessage.PromptShown(id)
                else if (payload.bool("returnValue") == false) LgMessage.Error(id, payload.str("errorText") ?: "İstek reddedildi")
                else LgMessage.Response(id, payload)
            "error" -> LgMessage.Error(id, m.str("error") ?: "Bilinmeyen hata")
            else -> LgMessage.Unknown
        }
    }

    /** Eski ve yeni yazılım biçimlerinden ses durumunu okur. */
    fun parseVolume(payload: Map<String, Any?>): Pair<Long?, Boolean?> {
        val vs = payload.obj("volumeStatus")
        val vol = vs?.long("volume") ?: payload.long("volume")
        val muted = vs?.bool("muteStatus") ?: payload.bool("muted") ?: payload.bool("mute")
        return vol to muted
    }
}
