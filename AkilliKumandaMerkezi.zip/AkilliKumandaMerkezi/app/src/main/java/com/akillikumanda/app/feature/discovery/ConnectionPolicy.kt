package com.akillikumanda.app.feature.discovery

import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.ConnectionType
import com.akillikumanda.app.core.model.DeviceCategory
import com.akillikumanda.app.core.model.RemoteProfile
import com.akillikumanda.app.platform.capability.NO_IR_MESSAGE

data class ConnectionOption(val type: ConnectionType, val usable: Boolean, val explanation: String)

const val VEHICLE_GUIDE =
    "Araç sistemleri yalnızca üreticinin resmî dijital anahtar uygulaması veya yetkili API'leri üzerinden kontrol edilebilir. " +
    "Bu uygulama araç anahtarı radyo sinyallerini yakalamaz, kopyalamaz, yeniden oynatmaz ve araç güvenlik sistemlerine müdahale etmez. " +
    "Şu anda desteklenen resmî bir araç entegrasyonu yok; aracınızın üreticisinin uygulamasını kullanın."

/** Wi-Fi ve Bluetooth kumandasının anlamlı olduğu kategoriler (ekranlı medya cihazları). */
private val SCREEN_DEVICES = setOf(DeviceCategory.TV, DeviceCategory.MEDIA_PLAYER, DeviceCategory.PROJECTOR, DeviceCategory.OTHER)

object ConnectionPolicy {

    fun catalogGap(category: DeviceCategory): String = when (category) {
        DeviceCategory.AC ->
            "Klimalar her tuşa basıldığında tüm durumu (mod, sıcaklık, fan) tek uzun çerçevede gönderir ve bu çerçeve markaya göre değişir. " +
                "Katalogda henüz doğrulanmış bir klima kodlayıcısı yok; uydurma kod kullanılmaz."
        DeviceCategory.VEHICLE -> VEHICLE_GUIDE
        else -> "Yerel katalogda bu kategori için henüz IR profili yok."
    }

    fun options(
        category: DeviceCategory,
        irUsable: Boolean,
        hasIrProfiles: Boolean,
        onLocalNetwork: Boolean,
        hidApiAvailable: Boolean,
    ): List<ConnectionOption> {
        if (category == DeviceCategory.VEHICLE) {
            return ConnectionType.entries.map { ConnectionOption(it, false, VEHICLE_GUIDE) }
        }
        val screen = category in SCREEN_DEVICES
        return listOf(
            ConnectionOption(
                ConnectionType.WIFI,
                usable = screen && onLocalNetwork,
                explanation = when {
                    category == DeviceCategory.AC -> "Klimaların Wi-Fi kontrolü üreticiye özel bulut hizmetleriyle yapılır; belgelenmiş yerel bir protokol desteklenmiyor."
                    !screen -> "Bu cihaz türü için Wi-Fi protokolü desteklenmiyor."
                    !onLocalNetwork -> "Telefon şu anda bir Wi-Fi ağına bağlı değil. TV ile aynı Wi-Fi ağına bağlanın."
                    else -> "Aynı ağdaki Samsung (2016+), LG webOS ve Roku cihazları bulunur. Marka ve model doğrudan cihazdan okunur; komutlar TV'ye iletilir ve TV'den durum okunabilir."
                },
            ),
            ConnectionOption(
                ConnectionType.BLE,
                usable = screen && hidApiAvailable,
                explanation = when {
                    !screen -> "Bu cihaz türü Bluetooth kumanda kabul etmez."
                    !hidApiAvailable -> "Bluetooth kumanda için Android 9 veya üstü ve Bluetooth donanımı gerekir."
                    else -> "Telefon, TV'ye Bluetooth kumanda (HID) olarak eşleşir. Android TV, Google TV, Fire TV ve Bluetooth klavye/kumanda kabul eden TV'lerde çalışır. Bazı telefon üreticileri bu özelliği kapatmıştır; kurulumda denetlenir."
                },
            ),
            ConnectionOption(
                ConnectionType.IR,
                usable = irUsable && hasIrProfiles,
                explanation = when {
                    !irUsable -> NO_IR_MESSAGE
                    !hasIrProfiles -> catalogGap(category)
                    else -> "Telefonun kızılötesi vericisiyle, yerel katalogdaki aday profiller tek tek test edilir. IR tek yönlüdür: model otomatik tespit edilemez."
                },
            ),
            ConnectionOption(ConnectionType.VENDOR, false,
                "Bu sürümde üretici bulut entegrasyonu yok. Cihazınızın kendi resmî uygulamasını kullanabilirsiniz."),
            ConnectionOption(ConnectionType.EXTERNAL_ACCESSORY, false,
                "Harici IR aksesuar (USB/Bluetooth IR verici) desteği henüz yok."),
        )
    }

    /**
     * Test için güvenli komutlar, öncelik sırasıyla. Güç en sona konur çünkü cihazı kapatabilir.
     * Klima için güç ve sıcaklık komutları test listesine hiç girmez.
     */
    fun safeTestCommands(profile: RemoteProfile): List<String> {
        val order = when (profile.category) {
            DeviceCategory.AC -> emptyList()
            else -> listOf(CommandIds.MUTE, CommandIds.VOL_UP, CommandIds.VOL_DOWN, CommandIds.HOME, CommandIds.MENU, CommandIds.POWER)
        }
        return order.filter { profile.command(it) != null }
    }

    fun testLabel(commandId: String, profile: RemoteProfile): String {
        val base = profile.command(commandId)?.name ?: commandId
        return if (commandId == CommandIds.POWER) "$base (cihazı kapatabilir)" else base
    }
}
