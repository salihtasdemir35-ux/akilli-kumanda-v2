package com.akillikumanda.app.platform.bluetooth

import com.akillikumanda.app.core.json.MiniJson
import com.akillikumanda.app.core.json.str

/** Kayıtlı Bluetooth kumandasının eşleştiği TV (host) bilgisi. */
data class BluetoothConfig(val address: String, val hostName: String?) {
    fun encode(): String = MiniJson.stringify(mapOf("type" to "bluetooth", "address" to address, "hostName" to hostName))

    companion object {
        private val MAC = Regex("^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$")
        fun decode(text: String?): BluetoothConfig? {
            val m = text?.let { MiniJson.parseObjectOrNull(it) } ?: return null
            if (m.str("type") != "bluetooth") return null
            val a = m.str("address")?.takeIf { MAC.matches(it) } ?: return null
            return BluetoothConfig(a.uppercase(), m.str("hostName"))
        }
    }
}
