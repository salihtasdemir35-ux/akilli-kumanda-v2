package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.model.RemoteProtocol

/** Ağda bulunan bir cihaz ve bu cihazdan okunan (tahmin edilmeyen) kimlik bilgileri. */
data class NetworkDevice(
    val ip: String,
    val name: String,
    val manufacturer: String?,
    val model: String?,
    val uniqueId: String?,
    val protocol: RemoteProtocol?,
    /** Bilginin nereden okunduğu (ör. "SSDP açıklaması", "Samsung API"). */
    val evidence: List<String>,
) {
    val supported: Boolean get() = protocol != null
}

/** Ağdan toplanan ham bilgiler. */
data class DeviceProbe(
    val ip: String,
    val responses: List<SsdpResponse> = emptyList(),
    val description: DeviceDescription? = null,
    val samsungInfo: SamsungDeviceInfo? = null,
    val rokuInfo: RokuDeviceInfo? = null,
)

/**
 * Protokolü yalnızca cihazın kendi yanıtındaki kanıta göre belirler.
 * Marka adından tahmin yapılmaz: ör. her "Samsung" aygıtı TV değildir; Samsung API yanıtı gerekir.
 */
object DeviceIdentifier {
    fun identify(p: DeviceProbe): NetworkDevice {
        val ev = mutableListOf<String>()
        val sts = p.responses.mapNotNull { it.st?.lowercase() }
        val servers = p.responses.mapNotNull { it.server?.lowercase() }
        val d = p.description
        val uid = p.rokuInfo?.serial ?: p.samsungInfo?.id ?: d?.udn ?: p.responses.firstNotNullOfOrNull { it.usn?.substringBefore("::") }

        p.rokuInfo?.let { r ->
            ev += "Roku ECP device-info yanıtı"
            return NetworkDevice(p.ip, r.userDeviceName ?: r.friendlyName ?: "Roku", "Roku",
                listOfNotNull(r.modelName, r.modelNumber?.let { "($it)" }).joinToString(" ").ifEmpty { null },
                uid, RemoteProtocol.ROKU_ECP, ev)
        }
        p.samsungInfo?.let { s ->
            ev += "Samsung TV API (8001/api/v2) yanıtı"
            return NetworkDevice(p.ip, s.name ?: d?.friendlyName ?: "Samsung TV", "Samsung",
                s.modelName ?: d?.modelName, uid,
                if (s.isTv) RemoteProtocol.SAMSUNG_TIZEN_WS else null, ev)
        }
        val isLgWebos = sts.any { "lge-com:service:webos-second-screen" in it } ||
            servers.any { "webos" in it }
        if (isLgWebos) {
            ev += "LG webOS ikinci ekran hizmeti ilanı (SSDP)"
            if (d != null) ev += "UPnP aygıt açıklaması"
            return NetworkDevice(p.ip, d?.friendlyName ?: "LG webOS TV", "LG", d?.modelName ?: d?.modelNumber, uid,
                RemoteProtocol.LG_WEBOS_SSAP, ev)
        }
        if (sts.any { it == "roku:ecp" }) {
            ev += "Roku ECP ilanı (device-info okunamadı)"
            return NetworkDevice(p.ip, d?.friendlyName ?: "Roku", "Roku", d?.modelName, uid, RemoteProtocol.ROKU_ECP, ev)
        }
        if (d != null) ev += "UPnP aygıt açıklaması"
        return NetworkDevice(p.ip, d?.friendlyName ?: p.ip, d?.manufacturer, listOfNotNull(d?.modelName, d?.modelNumber).distinct()
            .joinToString(" ").ifEmpty { null }, uid, null, ev)
    }
}
