package com.akillikumanda.app.platform.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * Yerel ağ HTTP/WebSocket istemcileri.
 * TV'ler (Samsung 8002, LG 3001) kendinden imzalı sertifika kullanır. Bu yüzden ayrı bir TLS istemcisi
 * vardır ve yalnızca özel IPv4 adreslerine bağlanmasına izin verilir; internet adreslerine kesinlikle kullanılmaz.
 */
object LanHttp {
    private val onlyLan = okhttp3.Interceptor { chain ->
        val host = chain.request().url.host
        if (!LanAddress.isPrivateIpv4(host)) throw java.io.IOException("Yalnızca yerel ağ adreslerine izin verilir: $host")
        chain.proceed(chain.request())
    }

    val plain: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(2500, TimeUnit.MILLISECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .addInterceptor(onlyLan)
        .build()

    val lanTls: OkHttpClient by lazy {
        val trustTv = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(trustTv), SecureRandom()) }
        plain.newBuilder()
            .sslSocketFactory(ctx.socketFactory, trustTv)
            .hostnameVerifier { host, _ -> LanAddress.isPrivateIpv4(host) }
            .build()
    }

    fun clientFor(url: String): OkHttpClient = if (url.startsWith("wss:") || url.startsWith("https:")) lanTls else plain

    class HttpResult(val code: Int, val body: String?)

    suspend fun get(url: String): HttpResult? = withContext(Dispatchers.IO) {
        runCatching {
            clientFor(url).newCall(Request.Builder().url(url).get().build()).execute().use { HttpResult(it.code, it.body?.string()) }
        }.getOrNull()
    }

    suspend fun getBody(url: String): String? = get(url)?.takeIf { it.code in 200..299 }?.body

    suspend fun post(url: String): HttpResult? = withContext(Dispatchers.IO) {
        runCatching {
            val body = ByteArray(0).toRequestBody("text/plain".toMediaType())
            clientFor(url).newCall(Request.Builder().url(url).post(body).build()).execute().use { HttpResult(it.code, it.body?.string()) }
        }.getOrNull()
    }
}
