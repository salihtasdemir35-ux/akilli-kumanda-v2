package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.model.CommandIds

data class RokuDeviceInfo(
    val modelName: String?, val modelNumber: String?, val userDeviceName: String?, val friendlyName: String?,
    val serial: String?, val powerMode: String?, val isTv: Boolean,
)

/** Roku External Control Protocol — Roku'nun yayımladığı yerel HTTP API'si (port 8060). */
object RokuProtocol {
    const val PORT = 8060

    val KEYS = mapOf(
        CommandIds.POWER to "Power", CommandIds.VOL_UP to "VolumeUp", CommandIds.VOL_DOWN to "VolumeDown",
        CommandIds.MUTE to "VolumeMute", CommandIds.CH_UP to "ChannelUp", CommandIds.CH_DOWN to "ChannelDown",
        CommandIds.UP to "Up", CommandIds.DOWN to "Down", CommandIds.LEFT to "Left", CommandIds.RIGHT to "Right",
        CommandIds.OK to "Select", CommandIds.BACK to "Back", CommandIds.HOME to "Home", CommandIds.MENU to "Info",
    )
    /** TV olmayan Roku (çubuk/kutu) ses, kanal ve güç tuşlarını desteklemez. */
    val TV_ONLY = setOf(CommandIds.POWER, CommandIds.VOL_UP, CommandIds.VOL_DOWN, CommandIds.MUTE, CommandIds.CH_UP, CommandIds.CH_DOWN)

    fun commandsFor(isTv: Boolean): List<String> = KEYS.keys.filter { isTv || it !in TV_ONLY }

    fun keypressUrl(ip: String, commandId: String): String? = KEYS[commandId]?.let { "http://$ip:$PORT/keypress/$it" }
    fun deviceInfoUrl(ip: String) = "http://$ip:$PORT/query/device-info"

    fun parseDeviceInfo(xml: String): RokuDeviceInfo? {
        if (!xml.contains("<device-info")) return null
        return RokuDeviceInfo(
            modelName = Xml.tag(xml, "model-name"), modelNumber = Xml.tag(xml, "model-number"),
            userDeviceName = Xml.tag(xml, "user-device-name"), friendlyName = Xml.tag(xml, "friendly-device-name"),
            serial = Xml.tag(xml, "serial-number"), powerMode = Xml.tag(xml, "power-mode"),
            isTv = Xml.tag(xml, "is-tv").equals("true", true),
        )
    }
}
