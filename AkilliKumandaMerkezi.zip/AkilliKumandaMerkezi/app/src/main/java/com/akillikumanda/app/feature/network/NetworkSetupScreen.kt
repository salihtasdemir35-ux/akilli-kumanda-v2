package com.akillikumanda.app.feature.network

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.akillikumanda.app.appContainer
import com.akillikumanda.app.core.designsystem.BannerKind
import com.akillikumanda.app.core.designsystem.SectionTitle
import com.akillikumanda.app.core.designsystem.StatusBanner
import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.DeviceCategory
import com.akillikumanda.app.platform.network.NetworkDevice

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkSetupScreen(category: DeviceCategory, onOpenRemote: (Long) -> Unit, onBack: () -> Unit) {
    val c = appContainer()
    val vm: NetworkSetupViewModel = viewModel { NetworkSetupViewModel(c.networkScanner, c.network, c.savedRemotes, category) }
    val s by vm.state.collectAsStateWithLifecycle()
    BackHandler { if (!vm.back()) onBack() }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Wi-Fi ile kumanda ekle") },
            navigationIcon = { IconButton(onClick = { if (!vm.back()) onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            s.status?.let { StatusBanner(it.text, it.kind, title = it.title, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }) }
            when (s.step) {
                NetStep.SCAN -> ScanStep(s, vm)
                NetStep.PAIR -> PairStep(s, vm)
                NetStep.TEST -> TestStep(s, vm)
                NetStep.SAVE -> SaveStep(s, vm, onOpenRemote)
                NetStep.DONE -> {
                    StatusBanner("\"${s.name}\" Kumandalarım'a kaydedildi.", BannerKind.SUCCESS, title = "Kaydedildi")
                    s.savedId?.let { id -> Button(onClick = { onOpenRemote(id) }, Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Kumandayı aç") } }
                }
            }
        }
    }
}

@Composable
private fun ScanStep(s: NetUiState, vm: NetworkSetupViewModel) {
    if (!s.onNetwork) {
        StatusBanner("Telefon bir Wi-Fi ağına bağlı değil. TV ile aynı Wi-Fi ağına bağlanıp yeniden deneyin.", BannerKind.WARNING, title = "Wi-Fi yok")
        Button(onClick = vm::scan, modifier = Modifier.fillMaxWidth()) { Text("Yeniden dene") }
        return
    }
    Text("TV'niz açık ve telefonla aynı Wi-Fi ağında olmalı.", style = MaterialTheme.typography.bodyMedium)
    if (s.scanning) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("Ağda cihaz aranıyor…")
        }
    }
    val supported = s.devices.filter { it.supported }
    val other = s.devices.filterNot { it.supported }
    if (supported.isNotEmpty()) {
        SectionTitle("Bulunan TV'ler")
        supported.forEach { DeviceCard(it, onClick = { vm.select(it) }) }
    } else if (s.scanned && !s.scanning) {
        StatusBanner(
            "Desteklenen TV bulunamadı. Kontrol edin: TV açık mı (bekleme modunda değil)? Telefon ve TV aynı ağda mı " +
                "(misafir ağı ve \"AP izolasyonu\" cihazları birbirinden gizler)? Samsung: Ayarlar › Genel › Harici Aygıt Yöneticisi › " +
                "Aygıt Bağlantı Yöneticisi açık olmalı. LG: Ayarlar › Genel › Mobil TV Açık / LG Connect Apps açık olmalı.",
            BannerKind.WARNING, title = "Sonuç yok")
    }
    if (other.isNotEmpty()) {
        SectionTitle("Ağdaki diğer cihazlar (desteklenmiyor)")
        other.forEach { d ->
            Text("• ${d.name}${d.model?.let { " · $it" } ?: ""} (${d.ip})", style = MaterialTheme.typography.bodySmall)
        }
    }
    Button(onClick = vm::scan, enabled = !s.scanning, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Yeniden tara")
    }
    SectionTitle("IP adresiyle ekle")
    Text("Tarama bulamazsa TV'nin IP adresini girin (TV'de Ayarlar › Ağ › Ağ durumu).", style = MaterialTheme.typography.bodySmall)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(s.manualIp, vm::setManualIp, label = { Text("IP adresi") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
        OutlinedButton(onClick = vm::probeManual, enabled = !s.scanning && s.manualIp.isNotBlank()) { Text("Sorgula") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeviceCard(d: NetworkDevice, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Tv, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(10.dp))
                Text(d.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            }
            Text("Marka: ${d.manufacturer ?: "—"}   Model: ${d.model ?: "cihaz bildirmedi"}", style = MaterialTheme.typography.bodyMedium)
            Text("${d.protocol?.title ?: ""} · ${d.ip}", style = MaterialTheme.typography.bodySmall)
            Text("Bilgi kaynağı: ${d.evidence.joinToString(", ")}", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PairStep(s: NetUiState, vm: NetworkSetupViewModel) {
    val d = s.selected ?: return
    Text("${d.name} ile bağlantı kuruluyor", style = MaterialTheme.typography.titleMedium)
    if (s.pairing) {
        LinearProgressIndicator(Modifier.fillMaxWidth())
        if (s.promptShown) StatusBanner("TV ekranında bir izin isteği görünmeli. TV'nin kendi kumandasıyla \"İzin ver / Evet\" seçin.",
            BannerKind.INFO, title = "TV'de onay verin")
    } else {
        Button(onClick = vm::retryPair, modifier = Modifier.fillMaxWidth()) { Text("Tekrar dene") }
    }
}

@Composable
private fun TestStep(s: NetUiState, vm: NetworkSetupViewModel) {
    val p = s.profile ?: return
    Text("${p.brand} ${p.model ?: ""}".trim(), style = MaterialTheme.typography.titleMedium)
    SectionTitle("TV'den okunan bilgi")
    when (val st = s.readState) {
        null -> Text("Okunuyor…", style = MaterialTheme.typography.bodySmall)
        else -> if (st.isEmpty()) Text("TV bu protokolde durum bilgisi döndürmedi.", style = MaterialTheme.typography.bodySmall)
        else st.forEach { (k, v) -> Text("$k: $v", style = MaterialTheme.typography.bodyMedium) }
    }
    TextButton(onClick = vm::readState) { Text("Yeniden oku") }
    SectionTitle("Komut testi")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(CommandIds.VOL_UP to Icons.Filled.Add, CommandIds.VOL_DOWN to Icons.Filled.Remove, CommandIds.MUTE to Icons.AutoMirrored.Filled.VolumeOff)
            .filter { (id, _) -> p.command(id) != null }
            .forEach { (id, icon) ->
                FilledTonalButton(onClick = { vm.send(id) }, enabled = !s.sending, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) {
                    Icon(icon, null); Spacer(Modifier.width(4.dp)); Text(CommandIds.label(id))
                }
            }
    }
    if (p.command(CommandIds.VOL_UP) == null) {
        FilledTonalButton(onClick = { vm.send(CommandIds.HOME) }, enabled = !s.sending, modifier = Modifier.fillMaxWidth()) { Text("Ana ekran") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = vm::worked, enabled = s.sentOk, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("Çalıştı") }
        OutlinedButton(onClick = vm::notWorked, enabled = s.sentOk, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("Çalışmadı") }
    }
}

@Composable
private fun SaveStep(s: NetUiState, vm: NetworkSetupViewModel, onOpenRemote: (Long) -> Unit) {
    OutlinedTextField(s.name, vm::setName, label = { Text("Kumanda adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(s.room, vm::setRoom, label = { Text("Oda (isteğe bağlı)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    s.duplicateId?.let { id -> OutlinedButton(onClick = { onOpenRemote(id) }, modifier = Modifier.fillMaxWidth()) { Text("Mevcut kumandayı aç") } }
    Button(onClick = vm::save, enabled = s.name.isNotBlank(), modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Kaydet") }
}
