package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.model.RemoteProtocol
import com.akillikumanda.app.platform.infrared.TransmitResult
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Wi-Fi kumandalarının oturumlarını yönetir. TV'nin IP adresi değişirse (DHCP), kayıtlı benzersiz
 * kimlikle ağ yeniden taranır ve yeni adres bulunursa güncellenmiş yapılandırma döndürülür.
 */
class NetworkRemoteController(private val scanner: NetworkScanner) {
    private val sessions = HashMap<String, NetworkSession>()
    private val mutex = Mutex()

    private fun key(c: NetworkConfig) = "${c.protocol}|${c.uniqueId ?: c.ip}"

    fun newSession(config: NetworkConfig): NetworkSession = when (config.protocol) {
        RemoteProtocol.ROKU_ECP -> RokuSession(config)
        RemoteProtocol.SAMSUNG_TIZEN_WS -> SamsungSession(config)
        RemoteProtocol.LG_WEBOS_SSAP -> LgSession(config)
        else -> error("${config.protocol} bir ağ protokolü değil")
    }

    /** Kumanda Bul'dan ilk eşleştirme. */
    suspend fun pair(device: NetworkDevice, secure: Boolean, mac: String?, onPrompt: () -> Unit): PairOutcome {
        val proto = device.protocol ?: return PairOutcome.Failed("Bu cihaz için desteklenen protokol yok")
        val cfg = NetworkConfig(proto, device.ip, device.uniqueId, secure, null, mac)
        val s = newSession(cfg)
        val r = s.connect(onPrompt)
        if (r is PairOutcome.Paired) mutex.withLock { sessions.put(key(r.config), s)?.takeIf { it !== s }?.close() } else s.close()
        return r
    }

    private suspend fun session(config: NetworkConfig): NetworkSession = mutex.withLock {
        sessions.getOrPut(key(config)) { newSession(config) }
    }

    /** @return gönderim sonucu ve (değiştiyse) güncellenmiş yapılandırma. */
    suspend fun send(config: NetworkConfig, commandId: String): Pair<TransmitResult, NetworkConfig?> {
        val s = session(config)
        val r = s.send(commandId)
        if (r !is TransmitResult.TransmissionError || config.uniqueId == null) return r to s.config.takeIf { it != config }
        // Adres değişmiş olabilir: aynı kimlikli cihazı ara.
        val found = scanner.scan(2500).firstOrNull { it.uniqueId == config.uniqueId && it.protocol == config.protocol }
            ?: return r to null
        if (found.ip == config.ip) return r to null
        val moved = config.copy(ip = found.ip)
        mutex.withLock { sessions.remove(key(config))?.close() }
        val s2 = session(moved)
        return s2.send(commandId) to s2.config
    }

    suspend fun readState(config: NetworkConfig): DeviceState = session(config).readState()

    suspend fun closeAll() = mutex.withLock { sessions.values.forEach { it.close() }; sessions.clear() }
}
