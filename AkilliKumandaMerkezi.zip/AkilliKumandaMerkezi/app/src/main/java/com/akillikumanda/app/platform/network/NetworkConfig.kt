package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.json.MiniJson
import com.akillikumanda.app.core.json.str
import com.akillikumanda.app.core.model.RemoteProtocol

/**
 * Kayıtlı Wi-Fi kumandasının bağlantı bilgisi (SavedRemoteEntity.connectionConfig içinde JSON).
 * token/clientKey, TV'nin eşleştirme onayı sonrası verdiği anahtardır; yalnızca bu telefonda saklanır.
 */
data class NetworkConfig(
    val protocol: RemoteProtocol,
    val ip: String,
    val uniqueId: String?,
    val secure: Boolean,
    val token: String?,
    /** TV'nin bildirdiği Wi-Fi MAC adresi; yalnızca Wake-on-LAN için. */
    val mac: String? = null,
) {
    fun encode(): String = MiniJson.stringify(linkedMapOf(
        "type" to "network", "protocol" to protocol.name, "ip" to ip, "uniqueId" to uniqueId,
        "secure" to secure, "token" to token, "mac" to mac,
    ))

    companion object {
        fun decode(text: String?): NetworkConfig? {
            val m = text?.let { MiniJson.parseObjectOrNull(it) } ?: return null
            if (m.str("type") != "network") return null
            val proto = m.str("protocol")?.let { RemoteProtocol.fromName(it) } ?: return null
            val ip = m.str("ip")?.takeIf { LanAddress.isPrivateIpv4(it) } ?: return null
            return NetworkConfig(proto, ip, m.str("uniqueId"), m["secure"] == true, m.str("token"), m.str("mac"))
        }
    }
}
