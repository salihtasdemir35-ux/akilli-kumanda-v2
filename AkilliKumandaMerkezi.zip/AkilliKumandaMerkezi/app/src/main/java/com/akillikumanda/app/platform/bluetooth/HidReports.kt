package com.akillikumanda.app.platform.bluetooth

import com.akillikumanda.app.core.model.CommandIds

sealed interface HidAction {
    /** USB HID klavye kullanım kodu (Keyboard/Keypad sayfası). */
    data class Keyboard(val usage: Int) : HidAction
    /** USB HID Consumer sayfası kullanım kodu (16 bit). */
    data class Consumer(val usage: Int) : HidAction
}

/**
 * Telefonun Bluetooth HID kumanda olarak gönderdiği raporlar.
 * Rapor 1: standart 8 baytlık klavye; Rapor 2: 16 bit Consumer Control.
 * Kodlar USB HID Usage Tables belgesinden alınmıştır.
 */
object HidReports {
    const val KEYBOARD_REPORT_ID = 1
    const val CONSUMER_REPORT_ID = 2

    val DESCRIPTOR: ByteArray = intArrayOf(
        // Klavye
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, KEYBOARD_REPORT_ID,
        0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
        0xC0,
        // Consumer Control
        0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, CONSUMER_REPORT_ID,
        0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
        0xC0,
    ).map { it.toByte() }.toByteArray()

    val ACTIONS: Map<String, HidAction> = mapOf(
        CommandIds.UP to HidAction.Keyboard(0x52), CommandIds.DOWN to HidAction.Keyboard(0x51),
        CommandIds.LEFT to HidAction.Keyboard(0x50), CommandIds.RIGHT to HidAction.Keyboard(0x4F),
        CommandIds.OK to HidAction.Keyboard(0x28),
        CommandIds.VOL_UP to HidAction.Consumer(0x00E9), CommandIds.VOL_DOWN to HidAction.Consumer(0x00EA),
        CommandIds.MUTE to HidAction.Consumer(0x00E2), CommandIds.POWER to HidAction.Consumer(0x0030),
        CommandIds.CH_UP to HidAction.Consumer(0x009C), CommandIds.CH_DOWN to HidAction.Consumer(0x009D),
        CommandIds.MENU to HidAction.Consumer(0x0040), CommandIds.HOME to HidAction.Consumer(0x0223),
        CommandIds.BACK to HidAction.Consumer(0x0224),
    )

    val COMMANDS: List<String> = ACTIONS.keys.toList()

    /** (raporKimliği, basma raporu, bırakma raporu) */
    fun reportsFor(commandId: String): Triple<Int, ByteArray, ByteArray>? = when (val a = ACTIONS[commandId]) {
        is HidAction.Keyboard -> Triple(KEYBOARD_REPORT_ID,
            byteArrayOf(0, 0, a.usage.toByte(), 0, 0, 0, 0, 0), ByteArray(8))
        is HidAction.Consumer -> Triple(CONSUMER_REPORT_ID,
            byteArrayOf((a.usage and 0xFF).toByte(), ((a.usage shr 8) and 0xFF).toByte()), ByteArray(2))
        null -> null
    }
}
