package com.akillikumanda.app.core.json

/**
 * Küçük, bağımlılıksız JSON okuyucu/yazıcı. TV protokol mesajları için kullanılır.
 * Nesne → Map<String, Any?>, dizi → List<Any?>, sayı → Long veya Double, true/false, null, String.
 */
object MiniJson {

    class ParseException(msg: String) : Exception(msg)

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.ws()
        val v = p.value()
        p.ws()
        if (p.i != text.length) throw ParseException("Fazladan karakter: ${p.i}")
        return v
    }

    fun parseObjectOrNull(text: String): Map<String, Any?>? =
        runCatching { parse(text) as? Map<String, Any?> }.getOrNull()

    fun stringify(v: Any?): String = StringBuilder().also { write(it, v) }.toString()

    private fun write(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is String -> quote(sb, v)
            is Boolean -> sb.append(v)
            is Int, is Long -> sb.append(v.toString())
            is Double -> sb.append(if (v % 1.0 == 0.0 && v in -1e15..1e15) v.toLong().toString() else v.toString())
            is Float -> write(sb, v.toDouble())
            is Map<*, *> -> {
                sb.append('{'); var first = true
                for ((k, value) in v) { if (!first) sb.append(','); first = false; quote(sb, k.toString()); sb.append(':'); write(sb, value) }
                sb.append('}')
            }
            is List<*> -> {
                sb.append('['); v.forEachIndexed { i, x -> if (i > 0) sb.append(','); write(sb, x) }; sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) when (c) {
            '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\"); '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t"); '\b' -> sb.append("\\b"); '\u000C' -> sb.append("\\f")
            else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
        }
        sb.append('"')
    }

    private class Parser(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            if (i >= s.length) throw ParseException("Beklenmeyen son")
            return when (val c = s[i]) {
                '{' -> obj(); '[' -> arr(); '"' -> str()
                't' -> lit("true", true); 'f' -> lit("false", false); 'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw ParseException("Beklenmeyen '$c' @$i")
            }
        }
        fun lit(w: String, v: Any?): Any? { if (!s.startsWith(w, i)) throw ParseException("Geçersiz değer @$i"); i += w.length; return v }
        fun obj(): Map<String, Any?> {
            i++; ws(); val m = LinkedHashMap<String, Any?>()
            if (i < s.length && s[i] == '}') { i++; return m }
            while (true) {
                ws(); if (i >= s.length || s[i] != '"') throw ParseException("Anahtar bekleniyordu @$i")
                val k = str(); ws(); expect(':'); ws(); m[k] = value(); ws()
                if (i >= s.length) throw ParseException("Kapanmamış nesne")
                if (s[i] == ',') { i++; continue }
                expect('}'); return m
            }
        }
        fun arr(): List<Any?> {
            i++; ws(); val l = ArrayList<Any?>()
            if (i < s.length && s[i] == ']') { i++; return l }
            while (true) {
                ws(); l += value(); ws()
                if (i >= s.length) throw ParseException("Kapanmamış dizi")
                if (s[i] == ',') { i++; continue }
                expect(']'); return l
            }
        }
        fun expect(c: Char) { if (i >= s.length || s[i] != c) throw ParseException("'$c' bekleniyordu @$i"); i++ }
        fun str(): String {
            i++; val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw ParseException("Kapanmamış metin")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) throw ParseException("Kapanmamış kaçış")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C'); 'n' -> sb.append('\n')
                            'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'u' -> { if (i + 4 > s.length) throw ParseException("Kısa \\u"); sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                            else -> throw ParseException("Geçersiz kaçış \\$e")
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun num(): Any {
            val start = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            val t = s.substring(start, i)
            return t.toLongOrNull() ?: t.toDoubleOrNull() ?: throw ParseException("Geçersiz sayı $t")
        }
    }
}

@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.obj(key: String): Map<String, Any?>? = this[key] as? Map<String, Any?>
fun Map<String, Any?>.str(key: String): String? = when (val v = this[key]) { null -> null; is String -> v; else -> v.toString() }
fun Map<String, Any?>.bool(key: String): Boolean? = when (val v = this[key]) {
    is Boolean -> v; is String -> v.equals("true", true) || v.equals("on", true); else -> null
}
fun Map<String, Any?>.long(key: String): Long? = when (val v = this[key]) {
    is Long -> v; is Double -> v.toLong(); is String -> v.toLongOrNull(); else -> null
}
