package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.json.MiniJson
import com.akillikumanda.app.core.json.obj
import com.akillikumanda.app.core.json.str
import com.akillikumanda.app.core.model.CommandIds
import java.util.Base64

data class SamsungDeviceInfo(
    val id: String?, val name: String?, val modelName: String?, val powerState: String?,
    val tokenAuth: Boolean, val isTv: Boolean, val wifiMac: String? = null,
)

sealed interface SamsungEvent {
    data class Connected(val token: String?) : SamsungEvent
    data object Unauthorized : SamsungEvent
    data object TimedOut : SamsungEvent
    data class Other(val event: String?) : SamsungEvent
}

/** Samsung Tizen TV'lerin (2016+) yerel uzaktan kumanda WebSocket kanalı. */
object SamsungProtocol {
    const val INFO_PORT = 8001
    const val WS_PORT = 8001
    const val WSS_PORT = 8002

    val KEYS = mapOf(
        CommandIds.POWER to "KEY_POWER", CommandIds.VOL_UP to "KEY_VOLUP", CommandIds.VOL_DOWN to "KEY_VOLDOWN",
        CommandIds.MUTE to "KEY_MUTE", CommandIds.CH_UP to "KEY_CHUP", CommandIds.CH_DOWN to "KEY_CHDOWN",
        CommandIds.SOURCE to "KEY_SOURCE", CommandIds.MENU to "KEY_MENU", CommandIds.UP to "KEY_UP",
        CommandIds.DOWN to "KEY_DOWN", CommandIds.LEFT to "KEY_LEFT", CommandIds.RIGHT to "KEY_RIGHT",
        CommandIds.OK to "KEY_ENTER", CommandIds.BACK to "KEY_RETURN", CommandIds.HOME to "KEY_HOME",
    )

    fun infoUrl(ip: String) = "http://$ip:$INFO_PORT/api/v2/"

    fun channelUrl(ip: String, secure: Boolean, appName: String, token: String?): String {
        val name = Base64.getEncoder().encodeToString(appName.toByteArray(Charsets.UTF_8))
        val base = if (secure) "wss://$ip:$WSS_PORT" else "ws://$ip:$WS_PORT"
        val tok = if (secure && !token.isNullOrBlank()) "&token=$token" else ""
        return "$base/api/v2/channels/samsung.remote.control?name=$name$tok"
    }

    fun keyMessage(commandId: String): String? = KEYS[commandId]?.let {
        MiniJson.stringify(mapOf("method" to "ms.remote.control", "params" to mapOf(
            "Cmd" to "Click", "DataOfCmd" to it, "Option" to "false", "TypeOfRemote" to "SendRemoteKey")))
    }

    fun parseEvent(text: String): SamsungEvent {
        val m = MiniJson.parseObjectOrNull(text) ?: return SamsungEvent.Other(null)
        return when (val e = m.str("event")) {
            "ms.channel.connect" -> SamsungEvent.Connected(m.obj("data")?.str("token"))
            "ms.channel.unauthorized" -> SamsungEvent.Unauthorized
            "ms.channel.timeOut" -> SamsungEvent.TimedOut
            else -> SamsungEvent.Other(e)
        }
    }

    fun parseInfo(json: String): SamsungDeviceInfo? {
        val m = MiniJson.parseObjectOrNull(json) ?: return null
        val d = m.obj("device") ?: return null
        val type = (d.str("type") ?: m.str("type")).orEmpty()
        return SamsungDeviceInfo(
            id = d.str("id") ?: m.str("id"),
            name = d.str("name") ?: m.str("name"),
            modelName = d.str("modelName"),
            powerState = d.str("PowerState"),
            tokenAuth = d.str("TokenAuthSupport").equals("true", true),
            isTv = type.contains("TV", ignoreCase = true),
            wifiMac = d.str("wifiMac"),
        )
    }
}
