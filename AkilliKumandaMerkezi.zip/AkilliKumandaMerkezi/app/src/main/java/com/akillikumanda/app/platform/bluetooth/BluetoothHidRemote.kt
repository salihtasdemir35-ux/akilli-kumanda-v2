package com.akillikumanda.app.platform.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.akillikumanda.app.platform.infrared.TransmitResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.Executors

sealed interface HidState {
    data class Unsupported(val reason: String) : HidState
    data object PermissionRequired : HidState
    data object BluetoothOff : HidState
    data object Starting : HidState
    /** Uygulama HID kumanda olarak kayıtlı; TV'nin bağlanması bekleniyor. */
    data object Ready : HidState
    data class Connecting(val name: String?) : HidState
    data class Connected(val name: String?, val address: String) : HidState
    data class Error(val message: String) : HidState
}

data class BondedDevice(val name: String?, val address: String)

/**
 * Telefonu Bluetooth HID kumandası (klavye + medya tuşları) olarak sunar.
 * Android 9 (API 28) ve sonrası gerekir; bazı üreticiler bu profili kapatır, bu çalışma zamanında denetlenir.
 * BLUETOOTH_SCAN veya konum izni istenmez: eşleştirmeyi TV başlatır.
 */
class BluetoothHidRemote(private val context: Context) {
    private val _state = MutableStateFlow<HidState>(HidState.Starting)
    val state: StateFlow<HidState> = _state.asStateFlow()
    private val impl: Impl? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) Impl() else null
    private val sendLock = Mutex()

    val adapter: BluetoothAdapter? get() = context.getSystemService(BluetoothManager::class.java)?.adapter

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
        else emptyArray()

    fun hasPermissions(): Boolean = requiredPermissions().all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    /** HID kaydını başlatır veya mevcut durumu yeniler. Tekrar çağrılması güvenlidir. */
    fun start() {
        if (impl == null) { _state.value = HidState.Unsupported("Bluetooth kumanda için Android 9 veya üstü gerekir."); return }
        val a = adapter ?: run { _state.value = HidState.Unsupported("Bu telefonda Bluetooth yok."); return }
        if (!hasPermissions()) { _state.value = HidState.PermissionRequired; return }
        if (!a.isEnabled) { _state.value = HidState.BluetoothOff; return }
        impl.start(a)
    }

    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<BondedDevice> {
        if (!hasPermissions()) return emptyList()
        return runCatching { adapter?.bondedDevices.orEmpty().map { BondedDevice(it.name, it.address) } }.getOrDefault(emptyList())
            .sortedBy { it.name ?: it.address }
    }

    fun connect(address: String): Boolean = impl?.connect(address) ?: false

    suspend fun send(commandId: String): TransmitResult = sendLock.withLock {
        val (id, press, release) = HidReports.reportsFor(commandId)
            ?: return TransmitResult.InvalidProfile("Bu tuş Bluetooth kumandada yok")
        val i = impl ?: return TransmitResult.UnsupportedHardware
        if (!hasPermissions()) return TransmitResult.PermissionDenied("Bluetooth izni verilmedi")
        if (_state.value !is HidState.Connected) return TransmitResult.TransmissionError("TV Bluetooth ile bağlı değil")
        if (!i.report(id, press)) return TransmitResult.TransmissionError("Bluetooth raporu gönderilemedi")
        delay(60)
        i.report(id, release)
        TransmitResult.Success
    }

    fun stop() { impl?.stop() }

    @RequiresApi(Build.VERSION_CODES.P)
    @SuppressLint("MissingPermission")
    private inner class Impl {
        private var hid: BluetoothHidDevice? = null
        private var host: BluetoothDevice? = null
        private var registered = false
        private var proxyRequested = false
        private val executor = Executors.newSingleThreadExecutor()

        private val callback = object : BluetoothHidDevice.Callback() {
            override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
                this@Impl.registered = registered
                if (!registered) { _state.value = HidState.Error("Bluetooth kumanda kaydı kaldırıldı"); return }
                if (pluggedDevice != null) {
                    host = pluggedDevice
                    _state.value = HidState.Connecting(runCatching { pluggedDevice.name }.getOrNull())
                    hid?.connect(pluggedDevice)
                } else if (_state.value !is HidState.Connected) _state.value = HidState.Ready
            }

            override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
                val name = runCatching { device.name }.getOrNull()
                when (state) {
                    BluetoothProfile.STATE_CONNECTED -> { host = device; _state.value = HidState.Connected(name, device.address) }
                    BluetoothProfile.STATE_CONNECTING -> _state.value = HidState.Connecting(name)
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        if (host?.address == device.address) host = null
                        if (registered) _state.value = HidState.Ready
                    }
                }
            }
        }

        private val listener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Akilli Kumanda", "Akilli Kumanda Merkezi", "Akilli Kumanda Merkezi",
                    BluetoothHidDevice.SUBCLASS1_COMBO, HidReports.DESCRIPTOR,
                )
                val ok = runCatching { h.registerApp(sdp, null, null, executor, callback) }.getOrDefault(false)
                if (!ok) _state.value = HidState.Unsupported(
                    "Telefon Bluetooth kumanda (HID) kaydını kabul etmedi. Bazı üreticiler bu özelliği kapatmıştır.")
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null; registered = false; proxyRequested = false
                _state.value = HidState.Error("Bluetooth HID hizmeti kapandı")
            }
        }

        fun start(a: BluetoothAdapter) {
            when {
                registered -> {
                    val h = host
                    _state.value = if (h != null && hid?.getConnectionState(h) == BluetoothProfile.STATE_CONNECTED)
                        HidState.Connected(runCatching { h.name }.getOrNull(), h.address) else HidState.Ready
                }
                proxyRequested -> {}
                else -> {
                    _state.value = HidState.Starting
                    proxyRequested = a.getProfileProxy(context, listener, BluetoothProfile.HID_DEVICE)
                    if (!proxyRequested) _state.value = HidState.Unsupported("Bu telefon Bluetooth HID cihaz profilini desteklemiyor.")
                }
            }
        }

        fun connect(address: String): Boolean {
            val h = hid ?: return false
            val d = runCatching { adapter?.getRemoteDevice(address) }.getOrNull() ?: return false
            _state.value = HidState.Connecting(runCatching { d.name }.getOrNull())
            return runCatching { h.connect(d) }.getOrDefault(false).also { if (!it) _state.value = HidState.Ready }
        }

        fun report(id: Int, data: ByteArray): Boolean {
            val h = hid ?: return false
            val d = host ?: return false
            return runCatching { h.sendReport(d, id, data) }.getOrDefault(false)
        }

        fun stop() {
            runCatching { hid?.unregisterApp() }
            runCatching { hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } }
            hid = null; registered = false; proxyRequested = false; host = null
        }
    }
}
