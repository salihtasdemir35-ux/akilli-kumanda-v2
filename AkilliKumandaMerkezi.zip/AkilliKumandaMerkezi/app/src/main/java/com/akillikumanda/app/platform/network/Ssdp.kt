package com.akillikumanda.app.platform.network

/** Yerel ağ adresi kontrolü: TV protokolleri yalnızca özel IPv4 adreslerine yönlendirilir. */
object LanAddress {
    fun isPrivateIpv4(host: String): Boolean {
        val p = host.split('.')
        if (p.size != 4) return false
        val o = p.map { it.toIntOrNull() ?: return false }
        if (o.any { it !in 0..255 }) return false
        return o[0] == 10 || (o[0] == 172 && o[1] in 16..31) || (o[0] == 192 && o[1] == 168) ||
            (o[0] == 169 && o[1] == 254)
    }
}

data class SsdpResponse(val ip: String, val location: String?, val st: String?, val usn: String?, val server: String?)

data class DeviceDescription(
    val friendlyName: String?, val manufacturer: String?, val modelName: String?,
    val modelNumber: String?, val modelDescription: String?, val deviceType: String?, val udn: String?,
)

object Ssdp {
    const val ADDRESS = "239.255.255.250"
    const val PORT = 1900

    /** TV'lerin yanıt verdiği arama hedefleri. ssdp:all bazı TV'lerde yanıtsız kalır; özel hedefler de sorulur. */
    val SEARCH_TARGETS = listOf(
        "ssdp:all",
        "roku:ecp",
        "urn:samsung.com:device:RemoteControlReceiver:1",
        "urn:lge-com:service:webos-second-screen:1",
        "urn:dial-multiscreen-org:service:dial:1",
        "urn:schemas-upnp-org:device:MediaRenderer:1",
    )

    fun mSearch(st: String, mx: Int = 2): String =
        "M-SEARCH * HTTP/1.1\r\nHOST: $ADDRESS:$PORT\r\nMAN: \"ssdp:discover\"\r\nMX: $mx\r\nST: $st\r\n\r\n"

    /** HTTP benzeri SSDP yanıtını ayrıştırır. Yanıt değilse null. */
    fun parseResponse(ip: String, text: String): SsdpResponse? {
        val lines = text.split("\r\n", "\n")
        val first = lines.firstOrNull()?.trim() ?: return null
        if (!first.startsWith("HTTP/1.1 200", true) && !first.startsWith("NOTIFY", true)) return null
        val h = HashMap<String, String>()
        for (l in lines.drop(1)) {
            val idx = l.indexOf(':')
            if (idx > 0) h[l.substring(0, idx).trim().uppercase()] = l.substring(idx + 1).trim()
        }
        return SsdpResponse(ip, h["LOCATION"], h["ST"] ?: h["NT"], h["USN"], h["SERVER"])
    }

    /** UPnP aygıt açıklaması XML'inden ilk <device> bilgilerini okur (basit, bağımlılıksız). */
    fun parseDescription(xml: String): DeviceDescription {
        val device = Regex("<device>(.*)</device>", RegexOption.DOT_MATCHES_ALL).find(xml)?.groupValues?.get(1) ?: xml
        fun tag(name: String) = Xml.tag(device, name)
        return DeviceDescription(tag("friendlyName"), tag("manufacturer"), tag("modelName"),
            tag("modelNumber"), tag("modelDescription"), tag("deviceType"), tag("UDN"))
    }
}

object Xml {
    fun tag(xml: String, name: String): String? =
        Regex("<(?:\\w+:)?${Regex.escape(name)}(?:\\s[^>]*)?>(.*?)</(?:\\w+:)?${Regex.escape(name)}>", RegexOption.DOT_MATCHES_ALL)
            .find(xml)?.groupValues?.get(1)?.let(::unescape)?.trim()?.ifEmpty { null }

    fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")
}
