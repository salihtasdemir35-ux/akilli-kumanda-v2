package com.akillikumanda.app.platform.network

import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.platform.infrared.TransmitResult
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

const val APP_REMOTE_NAME = "Akilli Kumanda Merkezi"

/** TV'den gerçekten okunan bilgiler (etiket → değer). */
typealias DeviceState = List<Pair<String, String>>

sealed interface PairOutcome {
    data class Paired(val config: NetworkConfig) : PairOutcome
    data class Failed(val reason: String) : PairOutcome
}

interface NetworkSession {
    val config: NetworkConfig
    /** Eşleştirme veya yeniden bağlanma. [onPrompt] TV ekranında onay istendiğinde çağrılır. */
    suspend fun connect(onPrompt: () -> Unit = {}): PairOutcome
    suspend fun send(commandId: String): TransmitResult
    suspend fun readState(): DeviceState
    fun close()
}

/** WebSocket'i coroutine dostu hale getiren küçük sarmalayıcı. */
internal class WsConnection(url: String) {
    val incoming = Channel<String>(Channel.UNLIMITED)
    val opened = CompletableDeferred<Unit>()
    @Volatile var closedReason: String? = null
    val socket: WebSocket = LanHttp.clientFor(url).newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) { opened.complete(Unit) }
        override fun onMessage(webSocket: WebSocket, text: String) { incoming.trySend(text) }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            closedReason = t.message ?: t::class.java.simpleName
            opened.completeExceptionally(t); incoming.close(t)
        }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            closedReason = "Bağlantı kapandı ($code)"; incoming.close()
        }
    })
    val isOpen: Boolean get() = opened.isCompleted && !opened.isCancelled && closedReason == null
    fun close() { runCatching { socket.close(1000, null) } }
}

private fun unreachable(detail: String?) =
    TransmitResult.TransmissionError("TV'ye ulaşılamadı${detail?.let { ": $it" } ?: ""}. TV açık ve telefonla aynı Wi-Fi ağında mı?")

// ---------------------------------------------------------------- Roku
class RokuSession(override var config: NetworkConfig) : NetworkSession {
    override suspend fun connect(onPrompt: () -> Unit): PairOutcome {
        val info = LanHttp.getBody(RokuProtocol.deviceInfoUrl(config.ip))?.let(RokuProtocol::parseDeviceInfo)
            ?: return PairOutcome.Failed("Roku cihazı yanıt vermedi")
        return PairOutcome.Paired(config.copy(uniqueId = info.serial ?: config.uniqueId))
    }

    override suspend fun send(commandId: String): TransmitResult {
        val url = RokuProtocol.keypressUrl(config.ip, commandId) ?: return TransmitResult.InvalidProfile("Roku'da bu tuş yok")
        val r = LanHttp.post(url) ?: return unreachable(null)
        return when (r.code) {
            in 200..299 -> TransmitResult.Success
            403 -> TransmitResult.PermissionDenied("Roku komutu reddetti. Roku'da Ayarlar › Sistem › Gelişmiş sistem ayarları › " +
                "Mobil uygulamalarla kontrol › Ağ erişimi: \"Varsayılan\" olmalı.")
            else -> TransmitResult.TransmissionError("Roku HTTP ${r.code} döndürdü")
        }
    }

    override suspend fun readState(): DeviceState {
        val i = LanHttp.getBody(RokuProtocol.deviceInfoUrl(config.ip))?.let(RokuProtocol::parseDeviceInfo) ?: return emptyList()
        return listOfNotNull(
            i.userDeviceName?.let { "Ad" to it }, i.modelName?.let { "Model" to it }, i.modelNumber?.let { "Model no" to it },
            i.powerMode?.let { "Güç durumu" to if (it.equals("PowerOn", true)) "Açık" else it },
        )
    }

    override fun close() {}
}

// ---------------------------------------------------------------- Samsung
class SamsungSession(override var config: NetworkConfig) : NetworkSession {
    private var ws: WsConnection? = null

    override suspend fun connect(onPrompt: () -> Unit): PairOutcome {
        close()
        val url = SamsungProtocol.channelUrl(config.ip, config.secure, APP_REMOTE_NAME, config.token)
        val c = WsConnection(url)
        ws = c
        val promptTimer = coroutineScope {
            val t = launch { delay(1500); onPrompt() }
            try {
                // TV ilk kez bağlanırken ekranda izin ister; kullanıcıya 45 sn tanınır.
                withTimeoutOrNull(45_000) {
                    for (msg in c.incoming) {
                        when (val e = SamsungProtocol.parseEvent(msg)) {
                            is SamsungEvent.Connected -> return@withTimeoutOrNull e
                            SamsungEvent.Unauthorized -> return@withTimeoutOrNull e
                            SamsungEvent.TimedOut -> return@withTimeoutOrNull e
                            is SamsungEvent.Other -> {}
                        }
                    }
                    null
                }
            } catch (e: Exception) { null } finally { t.cancel() }
        }
        return when (promptTimer) {
            is SamsungEvent.Connected -> {
                config = config.copy(token = promptTimer.token ?: config.token)
                PairOutcome.Paired(config)
            }
            SamsungEvent.Unauthorized -> { close(); PairOutcome.Failed("TV'de izin reddedildi. TV'de Ayarlar › Genel › Harici Aygıt Yöneticisi › Aygıt Bağlantı Yöneticisi › Aygıt listesi'nden bu uygulamaya izin verin.") }
            SamsungEvent.TimedOut -> { close(); PairOutcome.Failed("TV'deki izin isteği zaman aşımına uğradı") }
            else -> { close(); PairOutcome.Failed("TV'ye bağlanılamadı${c.closedReason?.let { ": $it" } ?: ""}") }
        }
    }

    override suspend fun send(commandId: String): TransmitResult {
        val msg = SamsungProtocol.keyMessage(commandId) ?: return TransmitResult.InvalidProfile("Samsung'da bu tuş yok")
        if (ws?.isOpen != true) {
            val r = connect()
            if (r is PairOutcome.Failed) {
                if (commandId == CommandIds.POWER && config.mac != null && wake(config.mac!!))
                    return TransmitResult.Success // TV kapalıyken açma isteği Wake-on-LAN ile gönderildi
                return TransmitResult.TransmissionError(r.reason)
            }
        }
        return if (ws?.socket?.send(msg) == true) TransmitResult.Success else unreachable(ws?.closedReason)
    }

    private suspend fun wake(mac: String): Boolean = withContext(Dispatchers.IO) {
        val pkt = WakeOnLan.magicPacket(mac) ?: return@withContext false
        runCatching {
            DatagramSocket().use { s ->
                s.broadcast = true
                repeat(3) { s.send(DatagramPacket(pkt, pkt.size, InetAddress.getByName("255.255.255.255"), 9)) }
            }
            true
        }.getOrDefault(false)
    }

    override suspend fun readState(): DeviceState {
        val i = LanHttp.getBody(SamsungProtocol.infoUrl(config.ip))?.let(SamsungProtocol::parseInfo) ?: return emptyList()
        return listOfNotNull(
            i.name?.let { "Ad" to it }, i.modelName?.let { "Model" to it },
            i.powerState?.let { "Güç durumu" to if (it.equals("on", true)) "Açık" else it },
        )
    }

    override fun close() { ws?.close(); ws = null }
}

// ---------------------------------------------------------------- LG webOS
class LgSession(override var config: NetworkConfig) : NetworkSession {
    private var ws: WsConnection? = null
    private var pointer: WsConnection? = null
    private val pending = ConcurrentHashMap<String, CompletableDeferred<LgMessage>>()
    private val ids = AtomicInteger(1)
    private var reader: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override suspend fun connect(onPrompt: () -> Unit): PairOutcome {
        close()
        val order = if (config.secure) listOf(true, false) else listOf(false, true)
        var lastError = "TV'ye bağlanılamadı"
        for (secure in order) {
            val c = WsConnection(LgProtocol.url(config.ip, secure))
            val opened = withTimeoutOrNull(4000) { runCatching { c.opened.await() }.isSuccess } == true
            if (!opened) { lastError = c.closedReason ?: lastError; c.close(); continue }
            c.socket.send(LgProtocol.registerMessage(config.token))
            val result = withTimeoutOrNull(if (config.token == null) 60_000 else 10_000) {
                for (msg in c.incoming) when (val m = LgProtocol.parse(msg)) {
                    is LgMessage.PromptShown -> onPrompt()
                    is LgMessage.Registered -> return@withTimeoutOrNull m
                    is LgMessage.Error -> return@withTimeoutOrNull m
                    else -> {}
                }
                null
            }
            when (result) {
                is LgMessage.Registered -> {
                    ws = c
                    config = config.copy(secure = secure, token = result.clientKey ?: config.token)
                    startReader(c)
                    return PairOutcome.Paired(config)
                }
                is LgMessage.Error -> { c.close(); return PairOutcome.Failed("TV isteği reddetti: ${result.error}") }
                else -> { lastError = "TV'de onay verilmedi veya yanıt gelmedi"; c.close() }
            }
        }
        return PairOutcome.Failed(lastError)
    }

    private fun startReader(c: WsConnection) {
        reader?.cancel()
        reader = scope.launch {
            runCatching {
                for (msg in c.incoming) {
                    val m = LgProtocol.parse(msg)
                    val id = when (m) { is LgMessage.Response -> m.id; is LgMessage.Error -> m.id; else -> null }
                    if (id != null) pending.remove(id)?.complete(m)
                }
            }
            pending.values.forEach { it.complete(LgMessage.Error(null, c.closedReason ?: "Bağlantı kapandı")) }
            pending.clear()
        }
    }

    private suspend fun ensure(): String? {
        if (ws?.isOpen == true) return null
        return (connect() as? PairOutcome.Failed)?.reason
    }

    private suspend fun call(uri: String, payload: Map<String, Any?> = emptyMap()): LgMessage {
        ensure()?.let { return LgMessage.Error(null, it) }
        val id = "req_${ids.getAndIncrement()}"
        val d = CompletableDeferred<LgMessage>()
        pending[id] = d
        if (ws?.socket?.send(LgProtocol.request(id, uri, payload)) != true) { pending.remove(id); return LgMessage.Error(id, "Gönderilemedi") }
        return withTimeoutOrNull(6000) { d.await() } ?: LgMessage.Error(id, "TV yanıt vermedi").also { pending.remove(id) }
    }

    private suspend fun pointerSocket(): WsConnection? {
        pointer?.takeIf { it.isOpen }?.let { return it }
        val r = call(LgProtocol.POINTER_URI) as? LgMessage.Response ?: return null
        val path = r.payload["socketPath"] as? String ?: return null
        val host = runCatching { java.net.URI(path).host }.getOrNull()
        if (host == null || !LanAddress.isPrivateIpv4(host)) return null
        val c = WsConnection(path)
        if (withTimeoutOrNull(4000) { runCatching { c.opened.await() }.isSuccess } != true) { c.close(); return null }
        pointer = c
        return c
    }

    override suspend fun send(commandId: String): TransmitResult {
        LgProtocol.BUTTONS[commandId]?.let { btn ->
            val p = pointerSocket() ?: return TransmitResult.TransmissionError("TV'nin yön tuşu kanalı açılamadı")
            return if (p.socket.send(LgProtocol.button(btn))) TransmitResult.Success else unreachable(p.closedReason)
        }
        if (commandId == CommandIds.MUTE) {
            val v = call(LgProtocol.GET_VOLUME_URI)
            val muted = (v as? LgMessage.Response)?.let { LgProtocol.parseVolume(it.payload).second } ?: false
            return toResult(call(LgProtocol.MUTE_URI, mapOf("mute" to !muted)))
        }
        val uri = LgProtocol.REQUESTS[commandId] ?: return TransmitResult.InvalidProfile("LG'de bu tuş yok")
        return toResult(call(uri))
    }

    private fun toResult(m: LgMessage) = when (m) {
        is LgMessage.Response -> TransmitResult.Success
        is LgMessage.Error -> TransmitResult.TransmissionError(m.error)
        else -> TransmitResult.TransmissionError("Beklenmeyen yanıt")
    }

    override suspend fun readState(): DeviceState {
        val out = mutableListOf<Pair<String, String>>()
        (call(LgProtocol.SYSTEM_INFO_URI) as? LgMessage.Response)?.payload?.let { p ->
            (p["modelName"] as? String)?.let { out += "Model" to it }
        }
        (call(LgProtocol.GET_VOLUME_URI) as? LgMessage.Response)?.payload?.let { p ->
            val (vol, muted) = LgProtocol.parseVolume(p)
            vol?.let { out += "Ses seviyesi" to it.toString() }
            muted?.let { out += "Sessiz" to if (it) "Evet" else "Hayır" }
        }
        return out
    }

    override fun close() {
        reader?.cancel(); reader = null
        pointer?.close(); pointer = null
        ws?.close(); ws = null
    }
}

