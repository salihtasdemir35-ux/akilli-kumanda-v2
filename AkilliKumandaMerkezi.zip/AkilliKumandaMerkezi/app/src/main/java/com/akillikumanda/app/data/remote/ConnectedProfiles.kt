package com.akillikumanda.app.data.remote

import com.akillikumanda.app.core.model.*
import com.akillikumanda.app.platform.bluetooth.HidReports
import com.akillikumanda.app.platform.network.LgProtocol
import com.akillikumanda.app.platform.network.NetworkDevice
import com.akillikumanda.app.platform.network.RokuProtocol
import com.akillikumanda.app.platform.network.SamsungProtocol

/** Wi-Fi ve Bluetooth kumandaları için profil üretir. Marka/model cihazdan okunan bilgidir. */
object ConnectedProfiles {

    private val HOLD = setOf(CommandIds.VOL_UP, CommandIds.VOL_DOWN)

    private fun commands(ids: List<String>) = ids.map {
        RemoteCommand(it, CommandIds.label(it), "", ProtocolData.Key(it),
            if (it in HOLD) RepeatPolicy.HOLD_REPEAT else RepeatPolicy.ONCE, DeviceStateRequirement.ANY)
    }

    fun forNetwork(device: NetworkDevice, category: DeviceCategory, rokuIsTv: Boolean): RemoteProfile? {
        val proto = device.protocol ?: return null
        val ids = when (proto) {
            RemoteProtocol.ROKU_ECP -> RokuProtocol.commandsFor(rokuIsTv)
            RemoteProtocol.SAMSUNG_TIZEN_WS -> SamsungProtocol.KEYS.keys.toList()
            RemoteProtocol.LG_WEBOS_SSAP -> LgProtocol.COMMANDS
            else -> return null
        }
        return RemoteProfile(
            id = "net.${proto.name.lowercase()}.${(device.uniqueId ?: device.ip).replace(Regex("[^A-Za-z0-9:._-]"), "")}",
            category = category, brand = device.manufacturer ?: "TV", model = device.model, modelPrefixes = emptyList(),
            protocol = proto, connectionType = ConnectionType.WIFI, carrierFrequencyHz = 0, commands = commands(ids),
            source = "Cihazdan okundu: " + device.evidence.joinToString(", ").ifEmpty { "ağ yanıtı" },
            license = "Cihaz üreticisinin yerel kontrol protokolü",
            verificationStatus = VerificationStatus.USER_CONFIRMED, version = 1,
        )
    }

    fun forBluetooth(hostName: String?, address: String, category: DeviceCategory): RemoteProfile = RemoteProfile(
        id = "bt.hid.${address.replace(":", "")}", category = category, brand = hostName ?: "Bluetooth cihaz", model = null,
        modelPrefixes = emptyList(), protocol = RemoteProtocol.BT_HID, connectionType = ConnectionType.BLE,
        carrierFrequencyHz = 0, commands = commands(HidReports.COMMANDS),
        source = "Bluetooth HID (USB HID Usage Tables)", license = "Standart HID kullanım kodları",
        verificationStatus = VerificationStatus.USER_CONFIRMED, version = 1,
    )
}
