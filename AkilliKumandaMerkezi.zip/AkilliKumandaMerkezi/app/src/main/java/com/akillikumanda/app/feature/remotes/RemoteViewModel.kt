package com.akillikumanda.app.feature.remotes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.akillikumanda.app.core.database.SavedRemoteEntity
import com.akillikumanda.app.core.designsystem.BannerKind
import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.ConnectionType
import com.akillikumanda.app.platform.bluetooth.BluetoothConfig
import com.akillikumanda.app.platform.bluetooth.BluetoothHidRemote
import com.akillikumanda.app.platform.bluetooth.HidState
import com.akillikumanda.app.platform.network.DeviceState
import com.akillikumanda.app.platform.network.NetworkConfig
import com.akillikumanda.app.platform.network.NetworkRemoteController
import com.akillikumanda.app.core.model.ProtocolData
import com.akillikumanda.app.core.model.RemoteProfile
import com.akillikumanda.app.core.model.VerificationStatus
import com.akillikumanda.app.data.remote.SavedRemoteRepository
import com.akillikumanda.app.data.settings.AppSettings
import com.akillikumanda.app.data.settings.SettingsRepository
import com.akillikumanda.app.feature.ac.AcCodecRegistry
import com.akillikumanda.app.feature.ac.AcState
import com.akillikumanda.app.feature.discovery.ConnectionPolicy
import com.akillikumanda.app.feature.discovery.StatusMessage
import com.akillikumanda.app.platform.infrared.InfraredTransmitter
import com.akillikumanda.app.platform.infrared.IrSignal
import com.akillikumanda.app.platform.infrared.TransmitResult
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

enum class RetestPhase { HIDDEN, READY, SENT }

data class RemoteUiState(
    val loading: Boolean = true,
    val entity: SavedRemoteEntity? = null,
    val profile: RemoteProfile? = null,
    val status: StatusMessage? = null,
    val acState: AcState = AcState(),
    val acStateEverSent: Boolean = false,
    val retest: RetestPhase = RetestPhase.HIDDEN,
    val retestCommand: String? = null,
    /** Wi-Fi kumandasında TV'den gerçekten okunan durum. */
    val deviceState: DeviceState? = null,
    val readingState: Boolean = false,
) {
    val connection: ConnectionType? get() = entity?.let { ConnectionType.fromName(it.connectionType) }
}

class RemoteViewModel(
    private val id: Long,
    private val repo: SavedRemoteRepository,
    private val infrared: InfraredTransmitter,
    private val network: NetworkRemoteController,
    val bluetooth: BluetoothHidRemote,
    settingsRepo: SettingsRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(RemoteUiState())
    val state: StateFlow<RemoteUiState> = _state.asStateFlow()
    val settings: StateFlow<AppSettings> = settingsRepo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val busy = AtomicBoolean(false)
    private var markedUsed = false

    val hidState: StateFlow<HidState> = bluetooth.state

    init {
        viewModelScope.launch {
            repo.observe(id).collect { e ->
                val first = _state.value.entity == null
                _state.update { it.copy(loading = false, entity = e, profile = e?.let(repo::profileOf)) }
                if (first && e != null) when (ConnectionType.fromName(e.connectionType)) {
                    ConnectionType.WIFI -> readDeviceState()
                    ConnectionType.BLE -> connectBluetooth()
                    else -> {}
                }
            }
        }
    }

    /** Kayıtlı yönteme göre gönderir: IR verici, yerel ağ veya Bluetooth HID. */
    private suspend fun dispatch(commandId: String): TransmitResult {
        val e = _state.value.entity ?: return TransmitResult.InvalidProfile("Kayıt yok")
        val p = _state.value.profile ?: return TransmitResult.InvalidProfile("Profil okunamadı")
        return when (ConnectionType.fromName(e.connectionType)) {
            ConnectionType.IR -> infrared.send(p, commandId)
            ConnectionType.WIFI -> {
                val cfg = NetworkConfig.decode(e.connectionConfig)
                    ?: return TransmitResult.InvalidProfile("Wi-Fi bağlantı bilgisi bozuk; kumandayı yeniden ekleyin")
                if (p.command(commandId) == null) return TransmitResult.InvalidProfile("Bu TV'de bu tuş yok")
                val (r, updated) = network.send(cfg, commandId)
                if (updated != null && updated != cfg) repo.setConnectionConfig(id, updated.encode())
                r
            }
            ConnectionType.BLE -> {
                if (bluetooth.state.value !is HidState.Connected) connectBluetooth()
                bluetooth.send(commandId)
            }
            else -> TransmitResult.InvalidProfile("Bu bağlantı türü desteklenmiyor")
        }
    }

    fun connectBluetooth() {
        bluetooth.start()
        val cfg = BluetoothConfig.decode(_state.value.entity?.connectionConfig) ?: return
        if (bluetooth.state.value is HidState.Ready) bluetooth.connect(cfg.address)
    }

    fun readDeviceState() {
        val cfg = NetworkConfig.decode(_state.value.entity?.connectionConfig) ?: return
        _state.update { it.copy(readingState = true) }
        viewModelScope.launch {
            val st = runCatching { network.readState(cfg) }.getOrDefault(emptyList())
            _state.update { it.copy(deviceState = st, readingState = false) }
        }
    }

    private fun successText(label: String): String = when (_state.value.connection) {
        ConnectionType.WIFI -> "\"$label\" TV'ye iletildi."
        ConnectionType.BLE -> "\"$label\" Bluetooth ile gönderildi."
        else -> "Sinyal gönderildi: $label — cihaz tepkisini kontrol edin."
    }

    val acCodecAvailable: Boolean
        get() = acCodecId()?.let { AcCodecRegistry.find(it) } != null

    private fun acCodecId(): String? =
        (_state.value.profile?.command(CommandIds.AC_STATE)?.protocolData as? ProtocolData.AcFullState)?.codecId

    /** Basılı tutma tekrarlarında önceki gönderim bitmeden yenisi kuyruğa alınmaz. */
    fun send(commandId: String) {
        val p = _state.value.profile ?: return
        if (!busy.compareAndSet(false, true)) return
        viewModelScope.launch {
            try {
                val r = dispatch(commandId)
                val label = p.command(commandId)?.name ?: commandId
                onResult(r, successText(label))
            } finally { busy.set(false) }
        }
    }

    fun sendAc(newState: AcState) {
        val p = _state.value.profile ?: return
        val codec = acCodecId()?.let { AcCodecRegistry.find(it) }
        if (codec == null) {
            _state.update { it.copy(status = StatusMessage("Bu klima profili için doğrulanmış kodlayıcı yok; sinyal gönderilmedi.", BannerKind.ERROR)) }
            return
        }
        if (!busy.compareAndSet(false, true)) return
        viewModelScope.launch {
            try {
                val r = infrared.sendRaw(IrSignal(p.carrierFrequencyHz, codec.encode(newState)))
                if (r == TransmitResult.Success) _state.update { it.copy(acState = newState, acStateEverSent = true) }
                onResult(r, "Tam durum gönderildi — klimanın tepkisini kontrol edin.")
            } finally { busy.set(false) }
        }
    }

    private suspend fun onResult(r: TransmitResult, successText: String) {
        val msg = when (r) {
            TransmitResult.Success -> {
                if (!markedUsed) { markedUsed = true; repo.markUsed(id) }
                StatusMessage(successText, BannerKind.INFO)
            }
            TransmitResult.UnsupportedHardware -> StatusMessage("Bu telefonda kullanılabilir IR verici yok.", BannerKind.ERROR)
            is TransmitResult.UnsupportedFrequency -> StatusMessage("Telefon ${r.requestedHz} Hz frekansını desteklemiyor.", BannerKind.ERROR)
            is TransmitResult.InvalidProfile -> StatusMessage(r.reason, BannerKind.ERROR)
            is TransmitResult.PermissionDenied -> StatusMessage(r.detail, BannerKind.ERROR)
            is TransmitResult.TransmissionError -> StatusMessage("Gönderim başarısız: ${r.detail}", BannerKind.ERROR)
            TransmitResult.Cancelled -> StatusMessage("İptal edildi", BannerKind.INFO)
        }
        _state.update { it.copy(status = msg) }
    }

    fun toggleFavorite() {
        val e = _state.value.entity ?: return
        viewModelScope.launch { repo.setFavorite(e.id, !e.favorite) }
    }

    fun openRetest() {
        val p = _state.value.profile ?: return
        _state.update { it.copy(retest = RetestPhase.READY, retestCommand = ConnectionPolicy.safeTestCommands(p).firstOrNull()) }
    }

    fun sendRetest() {
        val p = _state.value.profile ?: return
        val cmd = _state.value.retestCommand ?: return
        viewModelScope.launch {
            val r = dispatch(cmd)
            if (r == TransmitResult.Success) _state.update { it.copy(retest = RetestPhase.SENT) }
            else { onResult(r, ""); _state.update { it.copy(retest = RetestPhase.HIDDEN) } }
        }
    }

    fun finishRetest(worked: Boolean) {
        viewModelScope.launch {
            repo.setVerification(id, if (worked) VerificationStatus.USER_CONFIRMED else VerificationStatus.UNVERIFIED)
            _state.update {
                it.copy(retest = RetestPhase.HIDDEN, status = if (worked)
                    StatusMessage("Kumanda yeniden doğrulandı.", BannerKind.SUCCESS)
                else StatusMessage("Kumanda \"Doğrulanmadı\" olarak işaretlendi. Kumanda Bul ile başka bir profil deneyebilirsiniz.", BannerKind.WARNING))
            }
        }
    }

    fun dismissRetest() = _state.update { it.copy(retest = RetestPhase.HIDDEN) }

    override fun onCleared() { infrared.cancelActiveTest() }
}
