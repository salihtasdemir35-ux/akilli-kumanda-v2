package com.akillikumanda.app.feature.bluetooth

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.akillikumanda.app.appContainer
import com.akillikumanda.app.core.designsystem.BannerKind
import com.akillikumanda.app.core.designsystem.SectionTitle
import com.akillikumanda.app.core.designsystem.StatusBanner
import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.DeviceCategory
import com.akillikumanda.app.platform.bluetooth.HidState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BluetoothSetupScreen(category: DeviceCategory, onOpenRemote: (Long) -> Unit, onBack: () -> Unit) {
    val c = appContainer()
    val vm: BluetoothSetupViewModel = viewModel { BluetoothSetupViewModel(c.bluetoothHid, c.savedRemotes, category) }
    val s by vm.state.collectAsStateWithLifecycle()
    val hid by vm.hidState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        vm.onPermissionResult(res.values.all { it })
    }
    val enableLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }
    val discoverLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.refresh() }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Bluetooth kumanda") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") } })
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            s.status?.let { StatusBanner(it.text, it.kind, title = it.title, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }) }

            if (s.savedId != null) {
                StatusBanner("\"${s.name}\" Kumandalarım'a kaydedildi.", BannerKind.SUCCESS, title = "Kaydedildi")
                Button(onClick = { onOpenRemote(s.savedId!!) }, Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Kumandayı aç") }
                return@Column
            }

            when (val h = hid) {
                is HidState.Unsupported -> StatusBanner(h.reason + " Wi-Fi veya IR yöntemini kullanabilirsiniz.", BannerKind.ERROR, title = "Desteklenmiyor")
                HidState.PermissionRequired -> {
                    StatusBanner("Telefonun TV'ye kumanda olarak bağlanabilmesi için \"Yakındaki cihazlar\" izni gerekir. Konum izni istenmez.",
                        BannerKind.INFO, title = "İzin gerekli")
                    Button(onClick = { permLauncher.launch(vm.hid.requiredPermissions()) }, Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("İzin ver") }
                    if (s.permissionDeniedOnce) {
                        StatusBanner("İzin reddedildi. Bluetooth kumanda bu izin olmadan çalışamaz; isterseniz uygulama ayarlarından açabilirsiniz.", BannerKind.WARNING)
                        OutlinedButton(onClick = {
                            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)))
                        }, Modifier.fillMaxWidth()) { Text("Uygulama ayarlarını aç") }
                    }
                }
                HidState.BluetoothOff -> {
                    StatusBanner("Bluetooth kapalı.", BannerKind.WARNING)
                    Button(onClick = { runCatching { enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } },
                        Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Bluetooth'u aç") }
                }
                HidState.Starting -> Row { CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("Bluetooth kumanda hazırlanıyor…") }
                is HidState.Error -> {
                    StatusBanner(h.message, BannerKind.ERROR)
                    Button(onClick = vm::refresh, Modifier.fillMaxWidth()) { Text("Tekrar dene") }
                }
                HidState.Ready, is HidState.Connecting -> {
                    if (h is HidState.Connecting) Row { CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("${h.name ?: "TV"} bağlanıyor…") }
                    SectionTitle("1. Telefonu görünür yapın")
                    Button(onClick = {
                        runCatching { discoverLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                            .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)) }
                    }, Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Icon(Icons.Filled.Bluetooth, null); Spacer(Modifier.width(8.dp)); Text("2 dakika görünür yap") }
                    SectionTitle("2. TV'den eşleştirin")
                    Text("Android TV / Google TV: Ayarlar › Uzaktan kumandalar ve aksesuarlar › Aksesuar ekle.\n" +
                        "Fire TV: Ayarlar › Kumandalar ve Bluetooth cihazları › Diğer Bluetooth cihazları.\n" +
                        "Listede telefonunuzun Bluetooth adı görünür; seçin ve eşleştirme kodunu iki cihazda onaylayın.",
                        style = MaterialTheme.typography.bodyMedium)
                    if (s.bonded.isNotEmpty()) {
                        SectionTitle("veya daha önce eşleşmiş bir cihaza bağlanın")
                        s.bonded.forEach { d ->
                            OutlinedButton(onClick = { vm.connect(d.address) }, modifier = Modifier.fillMaxWidth()) {
                                Text("${d.name ?: "Adsız"} (${d.address})")
                            }
                        }
                    }
                }
                is HidState.Connected -> {
                    StatusBanner("Bağlı cihaz: ${h.name ?: h.address}. Bluetooth yalnızca cihazın adını bildirir; model bilgisi bu yolla alınamaz.",
                        BannerKind.SUCCESS, title = "Bağlandı")
                    if (!s.confirmed) {
                        SectionTitle("Komut testi")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(CommandIds.VOL_UP to Icons.Filled.Add, CommandIds.MUTE to Icons.AutoMirrored.Filled.VolumeOff, CommandIds.HOME to Icons.Filled.Home)
                                .forEach { (id, icon) ->
                                    FilledTonalButton(onClick = { vm.send(id) }, enabled = !s.sending, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) {
                                        Icon(icon, null); Spacer(Modifier.width(4.dp)); Text(CommandIds.label(id))
                                    }
                                }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = vm::worked, enabled = s.sentOk, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("Çalıştı") }
                            OutlinedButton(onClick = vm::notWorked, enabled = s.sentOk, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("Çalışmadı") }
                        }
                    } else {
                        OutlinedTextField(s.name, vm::setName, label = { Text("Kumanda adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(s.room, vm::setRoom, label = { Text("Oda (isteğe bağlı)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        s.duplicateId?.let { id -> OutlinedButton(onClick = { onOpenRemote(id) }, Modifier.fillMaxWidth()) { Text("Mevcut kumandayı aç") } }
                        Button(onClick = vm::save, enabled = s.name.isNotBlank(), modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Kaydet") }
                    }
                }
            }
        }
    }
}
