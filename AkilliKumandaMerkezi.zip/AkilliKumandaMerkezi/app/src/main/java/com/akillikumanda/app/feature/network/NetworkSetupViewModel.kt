package com.akillikumanda.app.feature.network

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.akillikumanda.app.core.designsystem.BannerKind
import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.DeviceCategory
import com.akillikumanda.app.core.model.RemoteProfile
import com.akillikumanda.app.core.model.RemoteProtocol
import com.akillikumanda.app.data.remote.ConnectedProfiles
import com.akillikumanda.app.data.remote.SaveResult
import com.akillikumanda.app.data.remote.SavedRemoteRepository
import com.akillikumanda.app.feature.discovery.StatusMessage
import com.akillikumanda.app.platform.infrared.TransmitResult
import com.akillikumanda.app.platform.network.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class NetStep { SCAN, PAIR, TEST, SAVE, DONE }

data class NetUiState(
    val step: NetStep = NetStep.SCAN,
    val onNetwork: Boolean = true,
    val scanning: Boolean = false,
    val scanned: Boolean = false,
    val devices: List<NetworkDevice> = emptyList(),
    val manualIp: String = "",
    val selected: NetworkDevice? = null,
    val pairing: Boolean = false,
    val promptShown: Boolean = false,
    val config: NetworkConfig? = null,
    val profile: RemoteProfile? = null,
    val sending: Boolean = false,
    val sentOk: Boolean = false,
    val readState: DeviceState? = null,
    val status: StatusMessage? = null,
    val name: String = "",
    val room: String = "",
    val savedId: Long? = null,
    val duplicateId: Long? = null,
)

class NetworkSetupViewModel(
    private val scanner: NetworkScanner,
    private val controller: NetworkRemoteController,
    private val repo: SavedRemoteRepository,
    private val category: DeviceCategory,
) : ViewModel() {
    private val _s = MutableStateFlow(NetUiState())
    val state: StateFlow<NetUiState> = _s.asStateFlow()
    private var job: Job? = null
    private var rokuIsTv = true
    private var samsungSecure = true
    private var samsungMac: String? = null

    init { scan() }

    fun scan() {
        if (!scanner.isOnLocalNetwork()) {
            _s.update { it.copy(onNetwork = false, scanned = true, devices = emptyList()) }
            return
        }
        job?.cancel()
        _s.update { it.copy(onNetwork = true, scanning = true, status = null) }
        job = viewModelScope.launch {
            val list = runCatching { scanner.scan() }.getOrElse {
                _s.update { s -> s.copy(status = StatusMessage("Tarama başarısız: ${it.message}", BannerKind.ERROR)) }
                emptyList()
            }
            _s.update { it.copy(scanning = false, scanned = true, devices = list) }
        }
    }

    fun setManualIp(v: String) = _s.update { it.copy(manualIp = v.filter { c -> c.isDigit() || c == '.' }.take(15)) }

    fun probeManual() {
        val ip = _s.value.manualIp.trim()
        if (!LanAddress.isPrivateIpv4(ip)) {
            _s.update { it.copy(status = StatusMessage("Geçerli bir yerel IP girin (ör. 192.168.1.25).", BannerKind.ERROR)) }
            return
        }
        _s.update { it.copy(scanning = true, status = null) }
        viewModelScope.launch {
            val d = scanner.probeAddress(ip)
            _s.update { s ->
                if (d == null) s.copy(scanning = false, status = StatusMessage("$ip adresinden yanıt alınamadı veya cihaz tanınmadı.", BannerKind.WARNING))
                else s.copy(scanning = false, devices = (listOf(d) + s.devices.filter { it.ip != d.ip }))
            }
        }
    }

    fun select(d: NetworkDevice) {
        if (!d.supported) return
        _s.update { it.copy(step = NetStep.PAIR, selected = d, pairing = true, promptShown = false, status = null) }
        job = viewModelScope.launch {
            // Protokole özgü ön bilgi: Roku'nun TV olup olmadığı, Samsung'un güvenli kanal ve MAC bilgisi.
            when (d.protocol) {
                RemoteProtocol.ROKU_ECP -> rokuIsTv = LanHttp.getBody(RokuProtocol.deviceInfoUrl(d.ip))
                    ?.let(RokuProtocol::parseDeviceInfo)?.isTv ?: true
                RemoteProtocol.SAMSUNG_TIZEN_WS -> LanHttp.getBody(SamsungProtocol.infoUrl(d.ip))?.let(SamsungProtocol::parseInfo)?.let {
                    samsungSecure = it.tokenAuth; samsungMac = it.wifiMac
                }
                else -> {}
            }
            val secure = when (d.protocol) { RemoteProtocol.SAMSUNG_TIZEN_WS -> samsungSecure; RemoteProtocol.LG_WEBOS_SSAP -> true; else -> false }
            val r = controller.pair(d, secure, samsungMac) { _s.update { it.copy(promptShown = true) } }
            when (r) {
                is PairOutcome.Paired -> {
                    val profile = ConnectedProfiles.forNetwork(d, category, rokuIsTv)
                    _s.update {
                        it.copy(step = NetStep.TEST, pairing = false, config = r.config, profile = profile,
                            status = StatusMessage("Bağlantı kuruldu. Şimdi bir komut gönderip TV'nin tepki verdiğini kontrol edin.", BannerKind.SUCCESS))
                    }
                    readState()
                }
                is PairOutcome.Failed -> _s.update { it.copy(pairing = false, status = StatusMessage(r.reason, BannerKind.ERROR, "Eşleştirme başarısız")) }
            }
        }
    }

    fun retryPair() { _s.value.selected?.let(::select) }

    fun send(commandId: String) {
        val cfg = _s.value.config ?: return
        if (_s.value.sending) return
        _s.update { it.copy(sending = true) }
        viewModelScope.launch {
            val (r, newCfg) = controller.send(cfg, commandId)
            _s.update {
                it.copy(sending = false, config = newCfg ?: it.config, sentOk = it.sentOk || r == TransmitResult.Success,
                    status = if (r == TransmitResult.Success)
                        StatusMessage("\"${CommandIds.label(commandId)}\" TV'ye iletildi. TV tepki verdi mi?", BannerKind.INFO)
                    else StatusMessage(describe(r), BannerKind.ERROR))
            }
        }
    }

    fun readState() {
        val cfg = _s.value.config ?: return
        viewModelScope.launch {
            val st = runCatching { controller.readState(cfg) }.getOrDefault(emptyList())
            _s.update { it.copy(readState = st) }
        }
    }

    fun worked() {
        val s = _s.value
        if (!s.sentOk) return
        val d = s.selected ?: return
        _s.update { it.copy(step = NetStep.SAVE, name = listOfNotNull(d.manufacturer, category.title).joinToString(" ")) }
    }

    fun notWorked() = _s.update {
        it.copy(status = StatusMessage("Komut TV'ye ulaştı ama etki görülmediyse bu model protokolün tüm tuşlarını desteklemiyor olabilir. " +
            "Başka bir tuş deneyin; olmazsa Bluetooth veya IR yöntemini kullanın. Hiçbir şey kaydedilmedi.", BannerKind.WARNING))
    }

    fun setName(v: String) = _s.update { it.copy(name = v.take(60), duplicateId = null) }
    fun setRoom(v: String) = _s.update { it.copy(room = v.take(40)) }

    fun save() {
        val s = _s.value
        val p = s.profile ?: return
        val cfg = s.config ?: return
        viewModelScope.launch {
            when (val r = repo.saveConfirmed(p, s.name, s.room, null, cfg.encode())) {
                is SaveResult.Saved -> _s.update { it.copy(step = NetStep.DONE, savedId = r.id) }
                is SaveResult.Duplicate -> _s.update { it.copy(duplicateId = r.existingId,
                    status = StatusMessage("Bu TV bu adla zaten kayıtlı.", BannerKind.WARNING)) }
                is SaveResult.Invalid -> _s.update { it.copy(status = StatusMessage(r.reason, BannerKind.ERROR)) }
            }
        }
    }

    fun back(): Boolean {
        val s = _s.value
        return when (s.step) {
            NetStep.SCAN, NetStep.DONE -> false
            NetStep.PAIR, NetStep.TEST -> { job?.cancel(); _s.update { it.copy(step = NetStep.SCAN, pairing = false, sentOk = false, readState = null, status = null) }; true }
            NetStep.SAVE -> { _s.update { it.copy(step = NetStep.TEST) }; true }
        }
    }

    companion object {
        fun describe(r: TransmitResult): String = when (r) {
            TransmitResult.Success -> "Gönderildi"
            TransmitResult.UnsupportedHardware -> "Donanım desteklenmiyor"
            is TransmitResult.UnsupportedFrequency -> "Frekans desteklenmiyor"
            is TransmitResult.InvalidProfile -> r.reason
            is TransmitResult.PermissionDenied -> r.detail
            is TransmitResult.TransmissionError -> r.detail
            TransmitResult.Cancelled -> "İptal edildi"
        }
    }
}
