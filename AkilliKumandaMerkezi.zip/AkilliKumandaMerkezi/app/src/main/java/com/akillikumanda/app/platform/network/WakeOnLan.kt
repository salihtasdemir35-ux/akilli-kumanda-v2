package com.akillikumanda.app.platform.network

/** Wake-on-LAN sihirli paketi: 6×0xFF + MAC adresinin 16 tekrarı. */
object WakeOnLan {
    fun parseMac(mac: String): ByteArray? {
        val parts = mac.trim().split(':', '-')
        if (parts.size != 6) return null
        return runCatching { parts.map { it.toInt(16).toByte() }.toByteArray() }.getOrNull()
    }

    fun magicPacket(mac: String): ByteArray? {
        val m = parseMac(mac) ?: return null
        val out = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) out[i] = 0xFF.toByte()
        for (r in 0 until 16) System.arraycopy(m, 0, out, 6 + r * 6, 6)
        return out
    }
}
