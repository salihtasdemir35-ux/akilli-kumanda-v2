package com.akillikumanda.app.platform.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/**
 * Yerel ağda TV keşfi. Genel port taraması yapılmaz: yalnızca SSDP (UPnP) ilanları dinlenir ve
 * ilan veren cihazların belgelenmiş bilgi uç noktaları okunur.
 */
class NetworkScanner(private val context: Context) {

    fun isOnLocalNetwork(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    suspend fun scan(listenMs: Long = 3500): List<NetworkDevice> = withContext(Dispatchers.IO) {
        val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
        val lock = runCatching { wifi?.createMulticastLock("akilli-kumanda-ssdp")?.apply { setReferenceCounted(false); acquire() } }.getOrNull()
        val responses = mutableListOf<SsdpResponse>()
        try {
            DatagramSocket(null as java.net.SocketAddress?).use { sock ->
                sock.reuseAddress = true
                sock.bind(InetSocketAddress(0))
                sock.soTimeout = 300
                val group = InetAddress.getByName(Ssdp.ADDRESS)
                repeat(2) {
                    for (st in Ssdp.SEARCH_TARGETS) {
                        val b = Ssdp.mSearch(st).toByteArray(Charsets.US_ASCII)
                        runCatching { sock.send(DatagramPacket(b, b.size, group, Ssdp.PORT)) }
                    }
                }
                val buf = ByteArray(8192)
                val end = System.currentTimeMillis() + listenMs
                while (System.currentTimeMillis() < end) {
                    ensureActive()
                    val pk = DatagramPacket(buf, buf.size)
                    try { sock.receive(pk) } catch (_: SocketTimeoutException) { continue }
                    val ip = pk.address?.hostAddress ?: continue
                    if (!LanAddress.isPrivateIpv4(ip)) continue
                    Ssdp.parseResponse(ip, String(pk.data, 0, pk.length, Charsets.UTF_8))?.let { responses += it }
                }
            }
        } finally {
            runCatching { lock?.release() }
        }
        coroutineScope {
            responses.groupBy { it.ip }.map { (ip, rs) -> async { probe(ip, rs) } }.awaitAll()
        }.map(DeviceIdentifier::identify)
            .sortedWith(compareByDescending<NetworkDevice> { it.supported }.thenBy { it.name.lowercase() })
    }

    /** Multicast'in engellendiği ağlar için: kullanıcının girdiği IP'nin belgelenmiş uç noktalarını sorgular. */
    suspend fun probeAddress(ip: String): NetworkDevice? {
        if (!LanAddress.isPrivateIpv4(ip)) return null
        val probe = probe(ip, emptyList(), forceAll = true)
        val dev = DeviceIdentifier.identify(probe)
        if (dev.supported) return dev
        // LG webOS yalnızca SSDP ile ilan verir; doğrudan girilen IP'de SSAP portu açıksa aday olarak sunulur.
        val lgPortOpen = withContext(Dispatchers.IO) {
            listOf(LgProtocol.WSS_PORT, LgProtocol.WS_PORT).any { port ->
                runCatching { Socket().use { it.connect(InetSocketAddress(ip, port), 1500); true } }.getOrDefault(false)
            }
        }
        return if (lgPortOpen) dev.copy(name = "LG webOS TV (IP ile)", manufacturer = "LG",
            protocol = com.akillikumanda.app.core.model.RemoteProtocol.LG_WEBOS_SSAP,
            evidence = dev.evidence + "SSAP portu (3000/3001) yanıt verdi") else dev.takeIf { it.evidence.isNotEmpty() }
    }

    private suspend fun probe(ip: String, rs: List<SsdpResponse>, forceAll: Boolean = false): DeviceProbe = coroutineScope {
        val loc = rs.firstNotNullOfOrNull { it.location }
            ?.takeIf { runCatching { java.net.URI(it).host }.getOrNull()?.let(LanAddress::isPrivateIpv4) == true }
        val descJob = async { loc?.let { LanHttp.getBody(it) }?.let { Ssdp.parseDescription(it) } }
        val hints = (rs.mapNotNull { it.st } + rs.mapNotNull { it.server }).joinToString(" ").lowercase()
        val rokuJob = async {
            if (forceAll || "roku" in hints) LanHttp.getBody(RokuProtocol.deviceInfoUrl(ip))?.let(RokuProtocol::parseDeviceInfo) else null
        }
        val desc = descJob.await()
        val maybeSamsung = forceAll || "samsung" in hints || "tizen" in hints ||
            desc?.manufacturer?.contains("Samsung", true) == true
        val samsung = if (maybeSamsung) LanHttp.getBody(SamsungProtocol.infoUrl(ip))?.let(SamsungProtocol::parseInfo) else null
        DeviceProbe(ip, rs, desc, samsung, rokuJob.await())
    }
}
