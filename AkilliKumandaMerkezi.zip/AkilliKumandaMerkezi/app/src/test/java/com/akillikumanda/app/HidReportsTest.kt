package com.akillikumanda.app

import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.platform.bluetooth.HidReports
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HidReportsTest {
    @Test fun descriptorIsBalanced() {
        val d = HidReports.DESCRIPTOR.map { it.toInt() and 0xFF }
        // Collection (0xA1) sayısı End Collection (0xC0) sayısına eşit olmalı (ana öğeler düzeyinde)
        var i = 0; var open = 0
        while (i < d.size) {
            val prefix = d[i]; val size = when (prefix and 0x03) { 3 -> 4; else -> prefix and 0x03 }
            if (prefix == 0xA1) open++
            if (prefix == 0xC0) open--
            i += 1 + size
        }
        assertEquals(d.size, i)
        assertEquals(0, open)
    }
    @Test fun volumeUpConsumerReport() {
        val (id, press, release) = HidReports.reportsFor(CommandIds.VOL_UP)!!
        assertEquals(HidReports.CONSUMER_REPORT_ID, id)
        assertArrayEquals(byteArrayOf(0xE9.toByte(), 0), press)
        assertArrayEquals(byteArrayOf(0, 0), release)
    }
    @Test fun homeIs16Bit() {
        val (_, press, _) = HidReports.reportsFor(CommandIds.HOME)!!
        assertArrayEquals(byteArrayOf(0x23, 0x02), press)
    }
    @Test fun arrowKeyboardReport() {
        val (id, press, release) = HidReports.reportsFor(CommandIds.UP)!!
        assertEquals(HidReports.KEYBOARD_REPORT_ID, id)
        assertEquals(8, press.size); assertEquals(0x52, press[2].toInt())
        assertTrue(release.all { it == 0.toByte() })
    }
    @Test fun sourceNotSupported() { assertEquals(null, HidReports.reportsFor(CommandIds.SOURCE)) }
}

class SmallConfigTest {
    @Test fun wakeOnLanPacket() {
        val p = com.akillikumanda.app.platform.network.WakeOnLan.magicPacket("AA:BB:CC:DD:EE:FF")!!
        assertEquals(102, p.size)
        assertEquals(0xFF.toByte(), p[0]); assertEquals(0xAA.toByte(), p[6]); assertEquals(0xFF.toByte(), p[101])
        assertEquals(null, com.akillikumanda.app.platform.network.WakeOnLan.magicPacket("zz"))
    }
    @Test fun bluetoothConfigRoundTrip() {
        val c = com.akillikumanda.app.platform.bluetooth.BluetoothConfig("A1:B2:C3:D4:E5:F6", "Android TV")
        assertEquals(c, com.akillikumanda.app.platform.bluetooth.BluetoothConfig.decode(c.encode()))
        assertEquals(null, com.akillikumanda.app.platform.bluetooth.BluetoothConfig.decode("""{"type":"bluetooth","address":"x"}"""))
    }
    @Test fun macStoredInNetworkConfig() {
        val c = com.akillikumanda.app.platform.network.NetworkConfig(
            com.akillikumanda.app.core.model.RemoteProtocol.SAMSUNG_TIZEN_WS, "192.168.1.2", null, false, null, "AA:BB:CC:DD:EE:FF")
        assertEquals(c, com.akillikumanda.app.platform.network.NetworkConfig.decode(c.encode()))
    }
}
