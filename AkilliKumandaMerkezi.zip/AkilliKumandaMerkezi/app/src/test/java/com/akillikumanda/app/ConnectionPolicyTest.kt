package com.akillikumanda.app

import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.ConnectionType
import com.akillikumanda.app.core.model.DeviceCategory
import com.akillikumanda.app.core.model.DeviceStateRequirement
import com.akillikumanda.app.core.model.ProtocolData
import com.akillikumanda.app.core.model.RemoteCommand
import com.akillikumanda.app.core.model.RepeatPolicy
import com.akillikumanda.app.feature.discovery.ConnectionPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConnectionPolicyTest {
    private fun opts(cat: DeviceCategory, ir: Boolean = false, prof: Boolean = true, lan: Boolean = false, hid: Boolean = false) =
        ConnectionPolicy.options(cat, ir, prof, lan, hid)

    @Test fun nothingAvailable_noOptionUsable() { assertTrue(opts(DeviceCategory.TV).none { it.usable }) }
    @Test fun irWithProfiles_onlyIrUsable() {
        assertEquals(listOf(ConnectionType.IR), opts(DeviceCategory.TV, ir = true).filter { it.usable }.map { it.type })
    }
    @Test fun noIrButWifiAndHid_tvStillControllable() {
        assertEquals(setOf(ConnectionType.WIFI, ConnectionType.BLE),
            opts(DeviceCategory.TV, lan = true, hid = true).filter { it.usable }.map { it.type }.toSet())
    }
    @Test fun acWithoutProfiles_notUsableEvenOnWifi() {
        assertFalse(opts(DeviceCategory.AC, ir = true, prof = false, lan = true, hid = true).any { it.usable })
    }
    @Test fun vehicle_neverUsable() {
        assertTrue(opts(DeviceCategory.VEHICLE, ir = true, lan = true, hid = true).none { it.usable })
    }
    @Test fun powerIsLastSafeCommand() {
        fun cmd(id: String) = RemoteCommand(id, id, "", ProtocolData.Scalar(1, 32), RepeatPolicy.ONCE, DeviceStateRequirement.ANY)
        val p = tvProfile(commands = listOf(cmd(CommandIds.POWER), cmd(CommandIds.VOL_UP), cmd(CommandIds.MUTE)))
        assertEquals(listOf(CommandIds.MUTE, CommandIds.VOL_UP, CommandIds.POWER), ConnectionPolicy.safeTestCommands(p))
    }
    @Test fun acHasNoBlindTestCommands() {
        val p = tvProfile().copy(category = DeviceCategory.AC)
        assertTrue(ConnectionPolicy.safeTestCommands(p).isEmpty())
    }
}
