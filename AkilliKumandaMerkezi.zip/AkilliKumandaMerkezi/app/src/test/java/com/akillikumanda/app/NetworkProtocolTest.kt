package com.akillikumanda.app

import com.akillikumanda.app.core.json.MiniJson
import com.akillikumanda.app.core.json.obj
import com.akillikumanda.app.core.json.str
import com.akillikumanda.app.core.model.CommandIds
import com.akillikumanda.app.core.model.RemoteProtocol
import com.akillikumanda.app.platform.network.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkProtocolTest {

    @Test fun privateAddresses() {
        listOf("192.168.1.20", "10.0.0.5", "172.16.3.4", "172.31.255.1").forEach { assertTrue(it, LanAddress.isPrivateIpv4(it)) }
        listOf("8.8.8.8", "172.32.0.1", "192.169.1.1", "abc", "1.2.3", "300.1.1.1").forEach { assertFalse(it, LanAddress.isPrivateIpv4(it)) }
    }

    @Test fun mSearchFormat() {
        val m = Ssdp.mSearch("roku:ecp")
        assertTrue(m.startsWith("M-SEARCH * HTTP/1.1\r\n"))
        assertTrue(m.contains("ST: roku:ecp\r\n"))
        assertTrue(m.endsWith("\r\n\r\n"))
    }

    @Test fun parseSsdpResponse() {
        val txt = "HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nST: roku:ecp\r\nUSN: uuid:roku:ecp:X00400ABCDEF\r\n" +
            "Ext: \r\nServer: Roku/9.3.0 UPnP/1.0 Roku/9.3.0\r\nLOCATION: http://192.168.1.42:8060/\r\n\r\n"
        val r = Ssdp.parseResponse("192.168.1.42", txt)!!
        assertEquals("roku:ecp", r.st); assertEquals("http://192.168.1.42:8060/", r.location)
        assertEquals(null, Ssdp.parseResponse("1.1.1.1", "M-SEARCH * HTTP/1.1\r\n"))
    }

    @Test fun parseUpnpDescription() {
        val xml = """<?xml version="1.0"?><root xmlns="urn:schemas-upnp-org:device-1-0"><specVersion><major>1</major></specVersion>
            <device><deviceType>urn:schemas-upnp-org:device:Basic:1</deviceType><friendlyName>[LG] webOS TV OLED55C1</friendlyName>
            <manufacturer>LG Electronics</manufacturer><modelName>OLED55C14LB</modelName><modelNumber>1.0</modelNumber>
            <UDN>uuid:12345678-aaaa</UDN></device></root>"""
        val d = Ssdp.parseDescription(xml)
        assertEquals("[LG] webOS TV OLED55C1", d.friendlyName)
        assertEquals("OLED55C14LB", d.modelName)
        assertEquals("uuid:12345678-aaaa", d.udn)
    }

    @Test fun rokuDeviceInfo() {
        val xml = """<?xml version="1.0" encoding="UTF-8" ?><device-info><serial-number>X00400ABCDEF</serial-number>
            <model-name>TCL 55S425</model-name><model-number>7105X</model-number><is-tv>true</is-tv>
            <user-device-name>Salon Roku TV</user-device-name><power-mode>PowerOn</power-mode></device-info>"""
        val i = RokuProtocol.parseDeviceInfo(xml)!!
        assertEquals("TCL 55S425", i.modelName); assertTrue(i.isTv); assertEquals("PowerOn", i.powerMode)
        val dev = DeviceIdentifier.identify(DeviceProbe("192.168.1.42", rokuInfo = i))
        assertEquals(RemoteProtocol.ROKU_ECP, dev.protocol)
        assertEquals("Salon Roku TV", dev.name)
        assertEquals("TCL 55S425 (7105X)", dev.model)
        assertEquals("X00400ABCDEF", dev.uniqueId)
        assertEquals("http://192.168.1.42:8060/keypress/VolumeUp", RokuProtocol.keypressUrl("192.168.1.42", CommandIds.VOL_UP))
    }

    @Test fun rokuStickHasNoVolumeCommands() {
        val cmds = RokuProtocol.commandsFor(isTv = false)
        assertFalse(cmds.contains(CommandIds.VOL_UP)); assertTrue(cmds.contains(CommandIds.OK))
    }

    @Test fun samsungInfoAndMessages() {
        val json = """{"device":{"FrameTVSupport":"false","PowerState":"on","TokenAuthSupport":"true",
            "id":"uuid:abc-123","modelName":"QE55Q60TAU","name":"[TV] Samsung Q60","type":"Samsung SmartTV"},
            "id":"uuid:abc-123","isSupport":"{}","name":"[TV] Samsung Q60","type":"Samsung SmartTV","version":"2.0.25"}"""
        val info = SamsungProtocol.parseInfo(json)!!
        assertEquals("QE55Q60TAU", info.modelName); assertTrue(info.tokenAuth); assertTrue(info.isTv); assertEquals("on", info.powerState)
        val dev = DeviceIdentifier.identify(DeviceProbe("192.168.1.30", samsungInfo = info))
        assertEquals(RemoteProtocol.SAMSUNG_TIZEN_WS, dev.protocol)
        assertEquals("QE55Q60TAU", dev.model)

        val url = SamsungProtocol.channelUrl("192.168.1.30", true, "Akıllı Kumanda", "1234")
        assertTrue(url.startsWith("wss://192.168.1.30:8002/api/v2/channels/samsung.remote.control?name="))
        assertTrue(url.endsWith("&token=1234"))
        val msg = MiniJson.parseObjectOrNull(SamsungProtocol.keyMessage(CommandIds.VOL_UP)!!)!!
        assertEquals("ms.remote.control", msg.str("method"))
        assertEquals("KEY_VOLUP", msg.obj("params")!!.str("DataOfCmd"))

        assertEquals(SamsungEvent.Connected("98765"),
            SamsungProtocol.parseEvent("""{"data":{"clients":[],"id":"x","token":"98765"},"event":"ms.channel.connect"}"""))
        assertEquals(SamsungEvent.Unauthorized, SamsungProtocol.parseEvent("""{"event":"ms.channel.unauthorized"}"""))
    }

    @Test fun samsungNonTvNotControllable() {
        val info = SamsungProtocol.parseInfo("""{"device":{"type":"Samsung Speaker","name":"Soundbar"}}""")!!
        assertEquals(null, DeviceIdentifier.identify(DeviceProbe("192.168.1.31", samsungInfo = info)).protocol)
    }

    @Test fun lgIdentifiedFromSsdpOnly() {
        val r = SsdpResponse("192.168.1.50", "http://192.168.1.50:1885/", "urn:lge-com:service:webos-second-screen:1", "uuid:x", "WebOS/4.1.0 UPnP/1.0")
        val dev = DeviceIdentifier.identify(DeviceProbe("192.168.1.50", listOf(r)))
        assertEquals(RemoteProtocol.LG_WEBOS_SSAP, dev.protocol)
    }

    @Test fun unknownDeviceNotGuessed() {
        val r = SsdpResponse("192.168.1.60", null, "upnp:rootdevice", "uuid:y", "Linux UPnP/1.0")
        val d = Ssdp.parseDescription("<root><device><manufacturer>LG Electronics</manufacturer><modelName>NAS</modelName></device></root>")
        val dev = DeviceIdentifier.identify(DeviceProbe("192.168.1.60", listOf(r), d))
        assertEquals(null, dev.protocol)
        assertEquals("NAS", dev.model)
    }

    @Test fun lgMessages() {
        val reg = MiniJson.parseObjectOrNull(LgProtocol.registerMessage("KEY1"))!!
        assertEquals("register", reg.str("type"))
        assertEquals("KEY1", reg.obj("payload")!!.str("client-key"))
        assertFalse(LgProtocol.registerMessage(null).contains("client-key"))

        assertEquals(LgMessage.PromptShown("register_0"),
            LgProtocol.parse("""{"type":"response","id":"register_0","payload":{"pairingType":"PROMPT","returnValue":true}}"""))
        assertEquals(LgMessage.Registered("register_0", "abcdef"),
            LgProtocol.parse("""{"type":"registered","id":"register_0","payload":{"client-key":"abcdef"}}"""))
        assertTrue(LgProtocol.parse("""{"type":"error","id":"register_0","error":"403 User denied access","payload":{}}""") is LgMessage.Error)
        assertTrue(LgProtocol.parse("""{"type":"response","id":"7","payload":{"returnValue":false,"errorText":"no"}}""") is LgMessage.Error)

        assertEquals(12L to false, LgProtocol.parseVolume(mapOf("volume" to 12L, "muted" to false)))
        assertEquals(20L to true, LgProtocol.parseVolume(mapOf("volumeStatus" to mapOf("volume" to 20L, "muteStatus" to true))))
        assertEquals("type:button\nname:UP\n\n", LgProtocol.button("UP"))
    }

    @Test fun networkConfigRoundTripAndRejectsPublicIp() {
        val c = NetworkConfig(RemoteProtocol.SAMSUNG_TIZEN_WS, "192.168.1.30", "uuid:abc", true, "1234")
        assertEquals(c, NetworkConfig.decode(c.encode()))
        assertEquals(null, NetworkConfig.decode(c.copy(ip = "8.8.8.8").encode()))
        assertEquals(null, NetworkConfig.decode("{bozuk"))
    }
}
