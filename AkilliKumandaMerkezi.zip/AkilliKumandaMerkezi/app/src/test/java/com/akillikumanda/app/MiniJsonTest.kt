package com.akillikumanda.app

import com.akillikumanda.app.core.json.MiniJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MiniJsonTest {
    @Test fun roundTrip() {
        val v = mapOf("a" to 1L, "b" to listOf(true, null, "x\"y\n"), "c" to mapOf("d" to 2.5))
        assertEquals(v, MiniJson.parse(MiniJson.stringify(v)))
    }
    @Test fun unicodeEscape() { assertEquals("ğ", MiniJson.parse("\"\\u011f\"")) }
    @Test fun brokenJsonThrows() {
        for (bad in listOf("{", "{\"a\":}", "[1,", "tru", "{\"a\":1}x", "\"abc")) {
            assertTrue(bad, runCatching { MiniJson.parse(bad) }.isFailure)
        }
    }
    @Test fun parseObjectOrNull_nonObject() { assertEquals(null, MiniJson.parseObjectOrNull("[1]")) }
}
